﻿
Namespace LightSwitchApplication

    Public Class Employee

        Private Sub SocialSecurityNumber_Validate(results As EntityValidationResultsBuilder)

            If CountryOfResidence = "US" AndAlso Len(SocialSecurityNumber) = 0 Then
                results.AddPropertyError("Social Security Number must be entered")
            End If

        End Sub
    End Class

End Namespace
