﻿
Namespace LightSwitchApplication

    Public Class HolidayRequest


        Private Sub StartDate_Validate(results As EntityValidationResultsBuilder)
            If Me.StartDate > Me.EndDate Then
                results.AddPropertyError("Start Date cannot be later than End Date")
            End If
        End Sub


    End Class

End Namespace
