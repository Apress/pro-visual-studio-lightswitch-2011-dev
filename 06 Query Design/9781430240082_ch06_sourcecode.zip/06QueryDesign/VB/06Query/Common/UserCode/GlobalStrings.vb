﻿Namespace LightSwitchApplication

    Public Class GlobalStrings  ' The name of your GlobalValueContainerDefinition

        Public Shared Function LoggedOnUser() As String ' The name of the GlobalValueDefinition
            Return Application.Current.User.Name
        End Function

    End Class
End Namespace
