﻿
Namespace LightSwitchApplication

    Public Class Order

    End Class

End Namespace
