﻿
Namespace LightSwitchApplication

    Public Class ProductImages

        Private Sub ProductPhoto_Validate(results As EntityValidationResultsBuilder)
            If Me.ProductPhoto IsNot Nothing Then
                Dim sizeInKB = Me.ProductPhoto.Length / 1024
                If sizeInKB > 512 Then
                    results.AddPropertyError("File Size cannot be > 512kb")
                End If
            End If
        End Sub
    End Class

End Namespace
