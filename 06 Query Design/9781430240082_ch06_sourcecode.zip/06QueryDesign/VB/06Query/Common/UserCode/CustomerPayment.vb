﻿Imports System.Text.RegularExpressions

Namespace LightSwitchApplication

    Public Class CustomerPayment

        Private Sub CreditCardNumber_Validate(results As EntityValidationResultsBuilder)

            Dim pattern As String = "(^(4|5)\d{3}-?\d{4}-?\d{4}-?\d{4}|(4|5)\d{15})|(^(6011)-?\d{4}-?\d{4}-?\d{4}|(6011)-?\d{12})|(^((3\d{3}))-\d{6}-\d{5}|^((3\d{14})))"

            If Not Me.CreditCardNumber Is Nothing Then
                If Not Regex.IsMatch(Me.CreditCardNumber, pattern) Then
                    results.AddPropertyError("Credit Card Number is not valid")
                End If
            End If

        End Sub
    End Class

End Namespace
