﻿
Namespace LightSwitchApplication

    Public Class Customer

        Private Sub test()
            Me.HasActiveSubscriptions()

        End Sub

    End Class

End Namespace
