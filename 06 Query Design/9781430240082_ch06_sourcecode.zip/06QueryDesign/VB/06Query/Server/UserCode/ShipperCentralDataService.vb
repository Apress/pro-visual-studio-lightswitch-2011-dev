﻿
Namespace LightSwitchApplication

    Public Class ShipperCentralDataService

        Private Sub Products_Validate(entity As Product, results As EntitySetValidationResultsBuilder)

        End Sub




    End Class

End Namespace
