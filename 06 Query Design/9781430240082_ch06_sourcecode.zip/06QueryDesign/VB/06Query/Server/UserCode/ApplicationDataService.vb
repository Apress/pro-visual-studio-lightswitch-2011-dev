﻿
Namespace LightSwitchApplication

    Public Class ApplicationDataService

        Private Sub Orders_Validate(entity As Order, results As EntitySetValidationResultsBuilder)
            If entity.OrderItems.Count() > 10 Then
                results.AddEntityError("Orders can only contain a maximum of 10 items")
            End If

        End Sub

        Private Sub CustomersWithOutstandingOrders_PreprocessQuery(ByRef query As System.Linq.IQueryable(Of LightSwitchApplication.Customer))
            query = query.Where(
                Function(custItem) custItem.Orders.Where(
                   Function(orderItem) orderItem.OrderStatus.OrderStatusID = 1).Any())

        End Sub

        Private Sub CustomersWithOrders_PreprocessQuery(ByRef query As System.Linq.IQueryable(Of LightSwitchApplication.Customer))
            query = query.Where(Function(custItem) custItem.Orders.Any())
        End Sub

        Private Sub CustomersWithoutOrders_PreprocessQuery(ByRef query As System.Linq.IQueryable(Of LightSwitchApplication.Customer))
            query = query.Where(Function(custItem) Not custItem.Orders.Any())
        End Sub

        Private Sub OrdersByMonthAndYear_PreprocessQuery(
            OrderMonth As System.Nullable(Of Integer),
            OrderYear As System.Nullable(Of Integer),
            ByRef query As System.Linq.IQueryable(Of LightSwitchApplication.Order))

            Dim orderMonth2 As Integer = OrderMonth.GetValueOrDefault(-1)
            Dim orderYear2 As Integer = OrderYear.GetValueOrDefault(1)

            query = query.Where(
                Function(orderItem) orderItem.OrderDate.Month = orderMonth2 AndAlso
                    orderItem.OrderDate.Year = orderYear2
                    )
        End Sub


        Private Sub OrdersByMonthAndYear_ExecuteFailed(
            OrderMonth As System.Nullable(Of Integer),
            OrderYear As System.Nullable(Of Integer),
            exception As Exception)

        End Sub




        Private Sub Top10ExpensiveProducts_PreprocessQuery(ByRef query As System.Linq.IQueryable(Of LightSwitchApplication.Product))
            query = query.OrderByDescending(
                Function(productItem) productItem.ProductPrice).Take(10)

        End Sub

        Private Sub OrdersSortedByCustomer_PreprocessQuery(ByRef query As System.Linq.IQueryable(Of LightSwitchApplication.Order))
            query = query.OrderBy(Function(order) order.Customer.Firstname)
        End Sub

        Private Sub CustomersSortedByOrders_PreprocessQuery(ByRef query As System.Linq.IQueryable(Of LightSwitchApplication.Customer))
            query = query.OrderBy(Function(custItem) custItem.Orders.Max(Function(ordItem) ordItem.OrderDate))
        End Sub


    End Class

End Namespace
