﻿
Namespace LightSwitchApplication

    Public Class RequiredValidationConditional502

        Private Sub RequiredValidationConditional502_InitializeDataWorkspace(saveChangesTo As System.Collections.Generic.List(Of Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Me.EmployeeProperty = New Employee()
            Property1 = "SSN is required only if Country Of Residence is set to 'US'"
        End Sub

        Private Sub RequiredValidationConditional502_Saved()
            ' Write your code here.
            Me.Close(False)
            Application.Current.ShowDefaultScreen(Me.EmployeeProperty)
        End Sub

    End Class

End Namespace