﻿
Namespace LightSwitchApplication

    Public Class ActionDeletgeSample604

        Private Sub ActionDeleteExample_Execute()
            ' Write your code here.
            Dim customerSurnames As String = ""
            Customers.ToList().ForEach(Function(item) customerSurnames = customerSurnames & item.Surname)

            ShowMessageBox(customerSurnames)


        End Sub
    End Class

End Namespace
