﻿
Namespace LightSwitchApplication

    Public Class FilterByChildItems608

        Private Sub FilterByChildItems608_InitializeDataWorkspace(saveChangesTo As System.Collections.Generic.List(Of Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Property1 = "This is a list of customers that have orders with an order status of 1. See the Query CustomersWithOutstandingOrders"
        End Sub

        Private Sub FilterByChildItems608_Activated()
            ' Write your code here.

        End Sub
    End Class

End Namespace
