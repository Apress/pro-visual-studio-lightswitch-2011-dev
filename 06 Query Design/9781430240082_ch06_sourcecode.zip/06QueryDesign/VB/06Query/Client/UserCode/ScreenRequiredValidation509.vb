﻿
Namespace LightSwitchApplication

    Public Class ScreenRequiredValidation509

        Private Sub ScreenRequiredValidation509_InitializeDataWorkspace(saveChangesTo As System.Collections.Generic.List(Of Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Me.ProductProperty = New Product()
        End Sub

        Private Sub ScreenRequiredValidation509_Saved()
            ' Write your code here.
            Me.Close(False)
            Application.Current.ShowDefaultScreen(Me.ProductProperty)
        End Sub

        Private Sub ProductProperty_Validate(results As ScreenValidationResultsBuilder)
            If Not Me.ProductProperty.RRP.HasValue Then
                results.AddPropertyError("RRP must be entered")
            End If

        End Sub
    End Class

End Namespace