﻿
Namespace LightSwitchApplication

    Public Class ChildCollectionValidate507

        Private Sub ChildCollectionValidate507_InitializeDataWorkspace(saveChangesTo As System.Collections.Generic.List(Of Microsoft.LightSwitch.IDataService))
            ' Write your code here.

            Property1 = "Maximum number of child Order Items is 10"
            Me.OrderProperty = New Order()

        End Sub

        Private Sub ChildCollectionValidate507_Saved()
            ' Write your code here.
            Me.Close(False)
            Application.Current.ShowDefaultScreen(Me.OrderProperty)
        End Sub

    End Class

End Namespace