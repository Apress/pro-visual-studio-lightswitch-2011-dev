﻿
Namespace LightSwitchApplication

    Public Class ExistsQuery610

        Private Sub ExistsQuery610_InitializeDataWorkspace(saveChangesTo As System.Collections.Generic.List(Of Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Property1 = "This is an example of an Exists/ or IN type query. See the query CustomersWithOrders"
        End Sub

        Private Sub ExistsQuery610_Activated()
            ' Write your code here.

        End Sub
    End Class

End Namespace
