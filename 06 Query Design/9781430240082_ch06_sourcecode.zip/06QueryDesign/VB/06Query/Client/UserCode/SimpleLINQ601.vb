﻿Imports System.Text

Namespace LightSwitchApplication

    Public Class SimpleLINQ601

        Private Sub ShowOrderStatusCodes_Execute()
            ' Write your code here.

            Dim message = New StringBuilder

            Dim items = From dataItem In DataWorkspace.ApplicationData.OrderStatuses
                    Where dataItem.OrderStatusID < 4
                    Order By dataItem.StatusDescription
            Select dataItem

            For Each item As OrderStatus In items
                message.AppendLine(String.Format("{0} - {1}", item.OrderStatusID, item.StatusDescription))
            Next

            ShowMessageBox(message.ToString, "Order Status Codes", MessageBoxOption.Ok)

        End Sub
    End Class

End Namespace
