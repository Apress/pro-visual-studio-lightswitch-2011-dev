﻿
Namespace LightSwitchApplication

    Public Class FileSizeValidation506

        Private Sub FileSizeValidation506_InitializeDataWorkspace(ByVal saveChangesTo As Global.System.Collections.Generic.List(Of Global.Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Me.ProductImagesProperty = New ProductImages()
        End Sub

        Private Sub FileSizeValidation506_Saved()
            ' Write your code here.
            Me.Close(False)
            Application.Current.ShowDefaultScreen(Me.ProductImagesProperty)
        End Sub

    End Class

End Namespace