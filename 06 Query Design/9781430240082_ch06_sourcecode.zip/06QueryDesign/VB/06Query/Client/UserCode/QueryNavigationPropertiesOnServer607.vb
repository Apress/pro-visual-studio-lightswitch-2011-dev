﻿
Namespace LightSwitchApplication

    Public Class QueryNavigationPropertiesOnServer607

        Private Sub QueryNavigationPropertyOnServer_Execute()
            ' Write your code here.

        End Sub

        Private Sub QueryNavigationPropertiesOnServer607_InitializeDataWorkspace(saveChangesTo As System.Collections.Generic.List(Of Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Property1 = "Create a cutomer, save, and click on the link to open it"
        End Sub

        Private Sub QueryNavigationPropertiesOnServer607_Activated()
            ' Write your code here.

        End Sub
    End Class

End Namespace
