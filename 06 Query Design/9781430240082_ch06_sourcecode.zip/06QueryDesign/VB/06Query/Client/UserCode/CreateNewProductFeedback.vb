﻿
Namespace LightSwitchApplication

    Public Class CreateNewProductFeedback

   

    End Class

End Namespace