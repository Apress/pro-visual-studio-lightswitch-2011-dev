﻿
Namespace LightSwitchApplication

    Public Class EditableHyperlinkCustom

        Private Sub EditableHyperlinkCustom_Activated()
            ' Write your code here.

            Dim hyperlinkCtrl = Me.FindControl("URL")

            hyperlinkCtrl.SetBinding(System.Windows.Controls.HyperlinkButton.NavigateUriProperty, "StringValue")
            hyperlinkCtrl.SetBinding(System.Windows.Controls.HyperlinkButton.ContentProperty, "Name")


            'AddHandler hyperlinkCtrl.ControlAvailable,
            '    Sub(sender As Object, e As ControlAvailableEventArgs)
            '        CType(e.Control, System.Windows.Controls.HyperlinkButton).TargetName = "_blank"
            '    End Sub


        End Sub

    End Class

End Namespace
