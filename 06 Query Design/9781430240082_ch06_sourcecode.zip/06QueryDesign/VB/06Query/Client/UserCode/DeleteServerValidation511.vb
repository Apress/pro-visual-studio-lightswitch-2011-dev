﻿
Namespace LightSwitchApplication

    Public Class DeleteServerValidation511

        Private Sub DeleteServerValidation511_InitializeDataWorkspace(saveChangesTo As System.Collections.Generic.List(Of Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Me.Customer2Property = New Customer2()
        End Sub

        Private Sub DeleteServerValidation511_Saved()
            ' Write your code here.
            Me.Close(False)
            Application.Current.ShowDefaultScreen(Me.Customer2Property)
        End Sub

        Private Sub DeleteServerValidation511_SaveError(exception As Exception, ByRef handled As Boolean)
            ' Write your code here.
            ' Un-delete deleted records that had server-side validation errors
            Dim validationExc = TryCast(exception, ValidationException)

            If validationExc IsNot Nothing Then
                Dim entities = From v In validationExc.ValidationResults
                        Let e = TryCast(v.Target, IEntityObject)
                        Where e IsNot Nothing AndAlso e.Details.EntityState = EntityState.Deleted
                            Select e
                For Each e In entities
                    e.Details.DiscardChanges()
                Next
            End If

        End Sub
    End Class

End Namespace