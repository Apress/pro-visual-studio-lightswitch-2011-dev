﻿
Namespace LightSwitchApplication

    Public Class QueryAndMethodSyntax602

        Private Sub QueryAndMethodSyntax_CanExecute(ByRef result As Boolean)
            ' Write your code here.

            'Example of Query Syntax
            Dim items = From dataItem In DataWorkspace.ApplicationData.Customers
                        Where dataItem.Surname = "Smith"
                        Order By dataItem.FirstName
            Select dataItem

            'Example of Method Syntax
            Dim items2 =
                From dataItem In DataWorkspace.ApplicationData.Customers.Where(
                    Function(cust) cust.Surname = "Smith").OrderBy(
                        Function(cust) cust.FirstName)
            Select dataItem


            Me.ShowMessageBox("To see examples of Query vs Method syntax, see the code behind the screen QueryAndMethodSyntax602")

        End Sub

        Private Sub QueryAndMethodSyntax_Execute()
            ' Write your code here.

        End Sub
    End Class

End Namespace
