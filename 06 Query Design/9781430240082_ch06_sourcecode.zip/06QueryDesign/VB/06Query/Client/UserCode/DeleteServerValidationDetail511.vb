﻿
Namespace LightSwitchApplication

    Public Class DeleteServerValidationDetail511

        Private Sub Customer2_Loaded(succeeded As Boolean)
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Customer2)
            Property1 = "Create some Active subscriptions (save the customer if necessary), then try deleting and saving the customer"
        End Sub

        Private Sub Customer2_Changed()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Customer2)
        End Sub

        Private Sub DeleteServerValidationDetail511_Saved()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Customer2)
        End Sub

        Private Sub Delete_Execute()
            ' Write your code here.
            If Not Customer2 Is Nothing Then
                Customer2.Delete()
            End If
        End Sub
    End Class

End Namespace