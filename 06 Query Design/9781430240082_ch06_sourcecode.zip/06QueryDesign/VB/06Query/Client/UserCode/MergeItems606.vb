﻿
Namespace LightSwitchApplication

    Public Class MergeItems606

        Private Sub MergeItems606_InitializeDataWorkspace(ByVal saveChangesTo As Global.System.Collections.Generic.List(Of Global.Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Me.OrderProperty = New Order()
        End Sub

        Private Sub MergeItems606_Saved()
            ' Write your code here.
            Me.Close(False)
            Application.Current.ShowDefaultScreen(Me.OrderProperty)
        End Sub

        Private Sub MergeLineItems_Execute()
            ' Write your code here.
            Dim duplicates = From line In OrderProperty.OrderItems
    Group line By line.Products Into prodGroup = Group, Count()
    Where (prodGroup.Count > 1)
    Select prodGroup

            For Each dup In duplicates
                Dim totalQty = dup.Sum(Function(line) line.Quantity)
                Dim firstLine = dup.First()
                firstLine.Quantity = totalQty
                dup.Except(
                     New OrderItem() {firstLine}).ToList().ForEach(Sub(line) line.Delete())
            Next

        End Sub
    End Class

End Namespace