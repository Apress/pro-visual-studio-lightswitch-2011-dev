﻿
Namespace LightSwitchApplication

    Public Class UniqueProductName503

        Private Sub UniqueProductName503_InitializeDataWorkspace(ByVal saveChangesTo As Global.System.Collections.Generic.List(Of Global.Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Me.ProductProperty = New Product()
        End Sub

        Private Sub UniqueProductName503_Saved()
            ' Write your code here.
            Me.Close(False)
            Application.Current.ShowDefaultScreen(Me.ProductProperty)
        End Sub

    End Class

End Namespace