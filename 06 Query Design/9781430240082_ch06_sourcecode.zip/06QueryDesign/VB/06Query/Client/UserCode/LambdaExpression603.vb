﻿
Namespace LightSwitchApplication

    Public Class LambdaExpression603

        Private Sub LamdaExpressionExample_Execute()
            ' Write your code here.
            '1. For Each Loop Example – involes many lines of code
            Dim foundCustomer As Customer = Nothing

            For Each cust As Customer In DataWorkspace.ApplicationData.Customers
                If cust.Surname = "smith" Then
                    foundCustomer = cust
                    Exit For
                End If
            Next

            '2. Query Syntax LINQ 
            Dim foundCustomer2 =
                (From cust In DataWorkspace.ApplicationData.Customers
                 Where cust.Surname = "smith").FirstOrDefault()


            '3.  Method Syntax LINQ & Lamda Expression 
            Dim foundCustomer3 As Customer =
                DataWorkspace.ApplicationData.Customers.Where(
                    Function(cust) cust.Surname = "smith").FirstOrDefault()

            Me.ShowMessageBox("To see examples of finding a customer using a Lambda expression, see the code behind the screen LambdaExpression603")


        End Sub
    End Class

End Namespace
