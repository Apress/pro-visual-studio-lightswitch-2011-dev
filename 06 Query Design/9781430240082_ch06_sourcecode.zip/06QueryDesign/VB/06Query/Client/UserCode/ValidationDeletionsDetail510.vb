﻿
Namespace LightSwitchApplication

    Public Class ValidationDeletionsDetail510

        Private Sub Customer_Loaded(succeeded As Boolean)
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Customer)
        End Sub

        Private Sub Customer_Changed()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Customer)
        End Sub

        Private Sub ValidationDeletionsDetail510_Saved()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Customer)
        End Sub

        Private Sub Customer_Validate(results As ScreenValidationResultsBuilder)

            If Me.DataWorkspace.ApplicationData.Details.HasChanges Then
                Dim changeSet As EntityChangeSet = _
                    Me.DataWorkspace.ApplicationData.Details.GetChanges()

                For Each cust In changeSet.DeletedEntities.OfType(Of Customer)()
                    If cust.HasSubscription = True Then
                        cust.Details.DiscardChanges()
                        results.AddScreenResult("Unable to remove this customer.", ValidationSeverity.Informational)
                    End If

                Next
            End If

        End Sub

        Private Sub Delete_Execute()
            ' Write your code here.
            Customer.Delete()
        End Sub

        Private Sub ValidationDeletionsDetail510_InitializeDataWorkspace(saveChangesTo As System.Collections.Generic.List(Of Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Property1 = "Check the Has Subscription checkbox (save if necessary) and try deleting the record"
        End Sub
    End Class

End Namespace