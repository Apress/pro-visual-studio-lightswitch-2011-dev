﻿
Namespace LightSwitchApplication


    Public Class ValidationResultsInCode501

    

       

        Private Sub ViewResultsInCode_Execute()
            ' Write your code here.

            ' Examples of calling the IsValidated and HasErrors properties on details screen
            'Dim firstnameValid As Boolean = Me.Details.Properties.Firstname.IsValidated
            'Dim firstnameHasErrors As Boolean = Me.Details.Properties.Firstname.ValidationResults.HasErrors

            Dim firstnameValid As Boolean = Me.EmployeeProperty.Details.Properties.FirstName.IsValidated
            Dim firstnameHasErrors As Boolean = Me.EmployeeProperty.Details.Properties.FirstName.ValidationResults.HasErrors

            ' Get a count of all results with a severity of 'Error'.
            Dim errorCount As Integer = Me.Details.ValidationResults.Errors.Count

            ' Concatenate the error messages into a single string.
            Dim allErrors As String = ""
            For Each result In Me.Details.ValidationResults
                allErrors += result.Message + " "
            Next

            Me.ShowMessageBox(allErrors)

        End Sub

        Private Sub ValidationResultsInCode501_InitializeDataWorkspace(saveChangesTo As System.Collections.Generic.List(Of Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Me.EmployeeProperty = New Employee()
        End Sub

        Private Sub ValidationResultsInCode501_Saved()
            ' Write your code here.
            Me.Close(False)
            Application.Current.ShowDefaultScreen(Me.EmployeeProperty)

        End Sub
    End Class

End Namespace
