﻿
Namespace LightSwitchApplication

    Public Class ValidateDeletions510

        Private Sub ValidateDeletions510_Saving(ByRef handled As Boolean)
            ' Write your code here.

        End Sub

        Private Sub ValidateDeletions510_InitializeDataWorkspace(saveChangesTo As System.Collections.Generic.List(Of Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Property1 = "Add a new customer, click on save, and open the customer in a new screen"
        End Sub
    End Class

End Namespace
