﻿
Namespace LightSwitchApplication

    Public Class QueryEntityCollection605

        Private Sub QueryEntityCollection605_InitializeDataWorkspace(saveChangesTo As System.Collections.Generic.List(Of Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Me.CustomerProperty = New Customer()

            Property1 = "Click on the Querying An Entity Collection button to display all orders dated 2010-06-08"

        End Sub

        Private Sub QueryEntityCollection605_Saved()
            ' Write your code here.
            '   Me.Close(False)
            Application.Current.ShowDefaultScreen(Me.CustomerProperty)
        End Sub

        Private Sub QueryingAnEntityCollection_Execute()
            ' Write your code here.
            Dim items = From ord In CustomerProperty.Orders
            Where ord.OrderDate = "2010-06-08"
            Select ord

            Dim str As String = ""
            For Each ord In items
                'code to consume the data would be added here
                str += ord.OrderDesc & " "
            Next

            ShowMessageBox(str)

        End Sub

     
    End Class

End Namespace