﻿
Namespace LightSwitchApplication

    Public Class QueryNavigationPropertiesOnServerDetails607

        Private Sub Customer_Loaded(succeeded As Boolean)
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Customer)
            Property1 = "Click on the Query Navigation Properties On Server button to display all orders dated 2010-06-08"
        End Sub

        Private Sub Customer_Changed()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Customer)
        End Sub

        Private Sub QueryNavigationPropertiesOnServerDetails607_Saved()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Customer)
        End Sub

        Private Sub QueryNavigationPropertiesOnServer_Execute()
            ' Write your code here.
            Dim items = From ord In Customer.OrdersQuery
            Where ord.OrderDate = "2010-06-08"
            Select ord
            Dim str As String = ""

            For Each ord As Order In items
                'code to consume the data would be added here
                str += ord.OrderDesc + ", "
            Next

            ShowMessageBox(str)

        End Sub

   
    End Class

End Namespace