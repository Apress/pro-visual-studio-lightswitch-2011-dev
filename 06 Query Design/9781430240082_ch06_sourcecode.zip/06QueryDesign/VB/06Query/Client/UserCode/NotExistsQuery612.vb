﻿
Namespace LightSwitchApplication

    Public Class NotExistsQuery612

        Private Sub NotExistsQuery612_InitializeDataWorkspace(saveChangesTo As System.Collections.Generic.List(Of Microsoft.LightSwitch.IDataService))
            ' Write your code here.

            Property1 = "This is an example of a NOT Exists/ or NOT IN type query. See the query CustomersWithoutOrders"
        End Sub

        Private Sub NotExistsQuery612_Activated()
            ' Write your code here.

        End Sub
    End Class

End Namespace
