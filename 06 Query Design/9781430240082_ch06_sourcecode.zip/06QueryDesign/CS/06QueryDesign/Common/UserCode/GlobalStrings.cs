﻿using System;

namespace LightSwitchApplication
{
    public class GlobalStrings  // The name of your GlobalValueContainerDefinition
    {
        public static String LoggedOnUser()  // The name of the GlobalValueDefinition
        {
            return Application.Current.User.Name;
        }
    }
}
