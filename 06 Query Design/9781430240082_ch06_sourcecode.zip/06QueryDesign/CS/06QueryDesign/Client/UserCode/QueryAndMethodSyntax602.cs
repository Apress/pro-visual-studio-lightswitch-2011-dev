﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
namespace LightSwitchApplication
{
    public partial class QueryAndMethodSyntax602
    {
        partial void QueryAndMethodSyntax_Execute()
        {

            //Example of Query Syntax
            var items =
            from dataItem in DataWorkspace.ApplicationData.Customers
            where dataItem.Surname == "Smith"
            orderby dataItem.Firstname
            select dataItem;

            //Example of Method Syntax
            var items2 =
            from dataItem in DataWorkspace.ApplicationData.Customers
            .Where(cust => cust.Surname == "Smith")
            .OrderBy(cust => cust.Firstname)
            select dataItem;

            // Write your code here.
            this.ShowMessageBox("To see examples of Query vs Method syntax, see the code behind the screen QueryAndMethodSyntax602");

        }
    }
}
