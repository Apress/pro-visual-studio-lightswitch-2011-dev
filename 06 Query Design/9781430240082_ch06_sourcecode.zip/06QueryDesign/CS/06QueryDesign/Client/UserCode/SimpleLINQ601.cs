﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
using System.Text;
namespace LightSwitchApplication
{
    public partial class SimpleLINQ601
    {
        partial void ShowOrderStatusCodes_Execute()
        {
            // Write your code here.
            StringBuilder message = new StringBuilder();

            var items = from dataItem in DataWorkspace.ApplicationData.OrderStatuses
                        where dataItem.OrderStatusID < 4
                        orderby dataItem.StatusDescription
                        select dataItem;

            foreach (OrderStatus item in items)
            {
                message.AppendLine(String.Format("{0} - {1}", item.OrderStatusID, item.StatusDescription));
            }

            this.ShowMessageBox(message.ToString(), "Order Status Codes", MessageBoxOption.Ok);

        }
    }
}
