﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
namespace LightSwitchApplication
{
    public partial class ExistsQuery610
    {
        partial void ExistsQuery610_Activated()
        {
            // Write your code here.
            Property1 = "This is an example of an Exists/ or IN type query. See the query CustomersWithOrders";
 
        }
    }
}
