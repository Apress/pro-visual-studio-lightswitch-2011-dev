﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;

namespace LightSwitchApplication
{
    public partial class MergeItems606
    {
        partial void MergeItems606_InitializeDataWorkspace(global::System.Collections.Generic.List<global::Microsoft.LightSwitch.IDataService> saveChangesTo)
        {
            // Write your code here.
            this.OrderProperty = new Order();
        }

        partial void MergeItems606_Saved()
        {
            // Write your code here.
            this.Close(false);
            Application.Current.ShowDefaultScreen(this.OrderProperty);
        }

        partial void MergeLineItems_Execute()
        {
            // Write your code here.
            var duplicates = from  line in this.OrderItems 
                             group line by line.Product into prodGroup
                             where prodGroup.Count() > 1
                             select prodGroup;

            foreach (var dup in duplicates)
            {
                var totalQuantity = dup.Sum(line => line.Quantity);
                var firstLine = dup.First();
                firstLine.Quantity = totalQuantity;
                dup.Except(
                    new OrderItem [] { firstLine }).ToList().ForEach(line => line.Delete());
            }

        }
    }
}