﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;

namespace LightSwitchApplication
{
    public partial class QueryNavigationPropertiesOnServerDetails607
    {
        partial void Customer_Loaded(bool succeeded)
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.Customer);
        }

        partial void Customer_Changed()
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.Customer);
        }

        partial void QueryNavigationPropertiesOnServerDetails607_Saved()
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.Customer);
        }

        partial void QueryNavigationPropertiesOnServer_Execute()
        {
            // Write your code here.

            var items = from ord in Customer.OrdersQuery
                        where ord.OrderDate == DateTime.Parse("2010-06-08")
                        select ord;

            string str = "";

            foreach (Order ord in items)
            {
                //code to consume the data would be added here
                str += ord.OrderDesc + ", ";
            }

            this.ShowMessageBox(str);

        }

        partial void QueryNavigationPropertiesOnServerDetails607_Activated()
        {
            // Write your code here.
            Property1 = "Click on the Query Navigation Properties On Server button to display all orders dated 2010-06-08";
 
        }
    }
}