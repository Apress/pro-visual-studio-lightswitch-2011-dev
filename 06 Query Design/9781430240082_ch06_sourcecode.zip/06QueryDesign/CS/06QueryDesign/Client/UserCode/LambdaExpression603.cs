﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
namespace LightSwitchApplication
{
    public partial class LambdaExpression603
    {
        partial void LamdaExpressionExample_Execute()
        {
            // Write your code here.

            //1. For Each Loop Example – involes many lines of code

            Customer foundCustomer = null;

            foreach (Customer cust in DataWorkspace.ApplicationData.Customers)
            {
                if (cust.Surname == "smith")
                {
                    foundCustomer = cust;
                    break;
                }
            }

            //2. Query Syntax LINQ 

            Customer foundCustomer2 = (from cust in DataWorkspace.ApplicationData.Customers
                                      where cust.Surname == "smith"
                                      select cust).FirstOrDefault();


            //3.  Method Syntax LINQ & Lamda Expression 
            Customer foundCustomer3 =
                DataWorkspace.ApplicationData.Customers.Where(
                    cust => cust.Surname == "smith").FirstOrDefault();

            this.ShowMessageBox("To see examples of finding a customer using a Lambda expression, see the code behind the screen LambdaExpression603");


        }
    }
}
