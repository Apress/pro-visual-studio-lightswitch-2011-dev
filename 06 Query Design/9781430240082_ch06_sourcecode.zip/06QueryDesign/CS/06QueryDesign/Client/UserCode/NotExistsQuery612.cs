﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
namespace LightSwitchApplication
{
    public partial class NotExistsQuery612
    {
        partial void NotExistsQuery612_Activated()
        {
            // Write your code here.
            Property1 = "This is an example of a NOT Exists/ or NOT IN type query. See the query CustomersWithoutOrders";
        }
    }
}
