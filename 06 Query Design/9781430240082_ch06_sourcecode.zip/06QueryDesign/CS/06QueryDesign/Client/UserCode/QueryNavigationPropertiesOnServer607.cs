﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
namespace LightSwitchApplication
{
    public partial class QueryNavigationPropertiesOnServer607
    {
        partial void QueryNavigationPropertiesOnServer607_Activated()
        {
            // Write your code here.
            Property1 = "Create a cutomer, save, and click on the link to open it";
   
        }
    }
}
