﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;

namespace LightSwitchApplication
{
    public partial class QueryEntityCollection605
    {
        partial void QueryEntityCollection605_InitializeDataWorkspace(global::System.Collections.Generic.List<global::Microsoft.LightSwitch.IDataService> saveChangesTo)
        {
            // Write your code here.
            
            this.CustomerProperty = new Customer();

            Property1 = "Create a customer - the QueryingAnEntityCollection returns all orders dated 2010-06-08";

        }

        partial void QueryEntityCollection605_Saved()
        {
            // Write your code here.
            //this.Close(false);
            Application.Current.ShowDefaultScreen(this.CustomerProperty);
        }

        partial void QueryingAnEntityCollection_Execute()
        {
            // Write your code here.
            var items = from ord in CustomerProperty.Orders
                        where ord.OrderDate == DateTime.Parse("2010-06-08")
                        select ord;

            string str = "";
            foreach (Order ord in items)
            {
                //code to consume the data would be added here
                str += ord.OrderDesc + " ";
            }

            this.ShowMessageBox(str);
        }
    }
}