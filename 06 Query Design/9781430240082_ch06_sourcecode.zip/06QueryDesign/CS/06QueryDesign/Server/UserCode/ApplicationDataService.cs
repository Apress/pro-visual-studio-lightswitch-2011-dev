﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Security.Server;
namespace LightSwitchApplication
{
    public partial class ApplicationDataService
    {
        partial void CustomersSortedByOrders_PreprocessQuery(ref IQueryable<Customer> query)
        {
            query = query.OrderBy(custItem => custItem.Orders.Max(ordItem => ordItem.OrderDate));
        }

        partial void CustomersWithOrders_PreprocessQuery(ref IQueryable<Customer> query)
        {
            query = query.Where (custItem => custItem.Orders.Any());
        }

        partial void CustomersWithoutOrders_PreprocessQuery(ref IQueryable<Customer> query)
        {
            query = query.Where(custItem => !custItem.Orders.Any());
        }

        partial void CustomersWithOutstandingOrders_PreprocessQuery(ref IQueryable<Customer> query)
        {
            query = query.Where
                    (item => item.Orders.Where(
                        orderItem => orderItem.OrderStatus.OrderStatusID == 1).Any());
        }

        partial void OrdersByMonthAndYear_PreprocessQuery(int? OrderMonth, int? OrderYear, ref IQueryable<Order> query)
        {

            int month = OrderMonth.GetValueOrDefault(-1);
            int year = OrderYear.GetValueOrDefault(-1);
            query = query.Where(
                order => order.OrderDate.Month == month
                  && order.OrderDate.Year == year); 

        }

        partial void OrdersSortedByCustomer_PreprocessQuery(ref IQueryable<Order> query)
        {
            query = query.OrderBy(order => order.Customer.Firstname);
        }

        partial void Top10ExpensiveProducts_PreprocessQuery(ref IQueryable<Product> query)
        {
            query = query.OrderByDescending(productItem => productItem.ProductPrice).Take(10);
        }
    }
}
