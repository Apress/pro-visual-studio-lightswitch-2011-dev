﻿
Namespace LightSwitchApplication

    Public Class Customer

        Private Sub Surname_IsReadOnly(ByRef result As Boolean)

        End Sub
    End Class

End Namespace
