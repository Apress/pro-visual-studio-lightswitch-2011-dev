﻿
Namespace LightSwitchApplication

    Public Class HolidayRequests

        Private Sub HolidayRequests_Created()

        End Sub
    End Class

End Namespace
