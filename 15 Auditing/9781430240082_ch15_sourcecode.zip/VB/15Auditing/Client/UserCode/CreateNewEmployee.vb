﻿
Namespace LightSwitchApplication

    Public Class CreateNewEmployee

        Private Sub CreateNewEmployee_InitializeDataWorkspace(saveChangesTo As System.Collections.Generic.List(Of Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Me.EmployeeProperty = New Employee()


            'Microsoft.LightSwitch.Threading.Dispatchers.Main.BeginInvoke(
            '              Sub()
            '                  AddHandler Me.Details.Properties.EmployeeProperty.Loader.ExecuteCompleted,
            '                      AddressOf Me.CustomerLoaderExecuted

            '                  'Me.Details.Properties.EmployeeProperty
            '              End Sub)



        End Sub


        Private Sub CreateNewEmployee_Created()

            Microsoft.LightSwitch.Threading.Dispatchers.Main.BeginInvoke(
            Sub()
                AddHandler DirectCast(
                    Me.EmployeeProperty, INotifyPropertyChanged
                    ).PropertyChanged, AddressOf CustomerFieldChanged
            End Sub)

        End Sub


        Private Sub CustomerFieldChanged(sender As Object, e As PropertyChangedEventArgs)
            If e.PropertyName = "SecurityVetted" Then
                ShowMessageBox("SecurityVetted changed")
                Me.FindControl("group").IsVisible = EmployeeProperty.SecurityVetted.GetValueOrDefault(False)
            End If
        End Sub


        'Private monitoredCustomer As Employee

        'Private Sub CustomerLoaderExecuted(sender As Object, e As Microsoft.LightSwitch.ExecuteCompletedEventArgs)
        '    ' This event handler will be invoked on the Main Dispatcher everytime the Loader finishes an execution.
        '    ' Therefore Me.Customer will always be correct since we are accessing the Loader's members on the same Dispatcher.
        '    If monitoredCustomer IsNot Me.EmployeeProperty Then
        '        If monitoredCustomer IsNot Nothing Then
        '            RemoveHandler TryCast(monitoredCustomer, INotifyPropertyChanged).PropertyChanged, AddressOf Me.CustomerChanged
        '        End If

        '        monitoredCustomer = Me.EmployeeProperty
        '        If monitoredCustomer IsNot Nothing Then
        '            AddHandler TryCast(monitoredCustomer, INotifyPropertyChanged).PropertyChanged, AddressOf Me.CustomerChanged
        '        End If
        '    End If
        'End Sub
        'Private Sub CustomerChanged(sender As Object, e As PropertyChangedEventArgs)
        '    ' Handles Customer's Property Change events on UI thread.
        '    Me.ShowMessageBox("CustomerChanged")
        'End Sub



        Private Sub CreateNewEmployee_Saved()
            ' Write your code here.
            'Me.Close(False)
            'Application.Current.ShowDefaultScreen(Me.EmployeeProperty)

            ShowMessageBox("Employee Saved", "Record Saved", MessageBoxOption.Ok)
            Me.EmployeeProperty = New Employee()

            'Me.OpenModalWindow (

        End Sub

        Private Sub CreateNewEmployee_Saving(ByRef handled As Boolean)


            Dim comment = Me.ShowInputBox(
    "Do you want to include any additional comments?",
    "Confirm Save", "")

            If Not comment Is Nothing AndAlso
                comment.Length > 0 Then
                Me.EmployeeProperty.City = "YES"
            End If

            '        If Me.ShowInputBox(
            '"Are you sure you want to discard your changes?",
            '"Confirm Save", "") =
            'System.Windows.MessageBoxResult.Yes Then
            '            Me.DataWorkspace.ApplicationData.Details.DiscardChanges()
            '            Me.ShowMessageBox("The changes have been discarded")
            '        End If



        End Sub

        Private Sub CreateNewEmployee_SaveError(exception As System.Exception, ByRef handled As Boolean)

        End Sub


        Private Sub EmployeeProperty_Changed()

        End Sub

        Private Sub EmployeeProperty_Validate(results As Microsoft.LightSwitch.Framework.Client.ScreenValidationResultsBuilder)

        End Sub


        Private Sub CreateNewEmployee_Closing(ByRef cancel As Boolean)

        End Sub

        Private Sub CreateNewEmployee_Activated()

        End Sub

        Private Sub DiscardChanges_Execute()
            ' Write your code here.

        End Sub

    End Class

End Namespace