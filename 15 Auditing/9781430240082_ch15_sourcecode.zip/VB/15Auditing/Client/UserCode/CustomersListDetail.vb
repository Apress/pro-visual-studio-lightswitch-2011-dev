﻿
Namespace LightSwitchApplication

    Public Class CustomersListDetail

    End Class

End Namespace
