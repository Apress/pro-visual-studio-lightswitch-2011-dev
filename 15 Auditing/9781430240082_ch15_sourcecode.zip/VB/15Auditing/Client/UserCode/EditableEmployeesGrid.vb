﻿
Namespace LightSwitchApplication

    Public Class EditableEmployeesGrid


        Dim mwh As ModalWindowHelper

        Private Sub EditableEmployeesGrid_InitializeDataWorkspace(saveChangesTo As System.Collections.Generic.List(Of Microsoft.LightSwitch.IDataService))

            mwh = New ModalWindowHelper(Me.Employees, "Employees_Group", "Item")

            AddHandler Me.FindControl("grid").ControlAvailable,
             Sub(send As Object, e As ControlAvailableEventArgs)
                 itemsControl = TryCast(e.Control, System.Windows.Controls.DataGrid)
             End Sub



        End Sub



        Private Sub ModalWindowView_Execute()
            ' Write your code here.
            mwh.ViewEntity()
        End Sub

        Private Sub ModalWindowAdd_Execute()
            ' Write your code here.
            mwh.AddEntity()
        End Sub

        Private Sub EditableEmployeesGrid_Created()
            ' Write your code here.

            mwh.Initialise(hasCloseButton:=True, saveOnClose:=True)

            'Me.FindControlInCollection("RegionProperty", Employees ).

            'RegionProperty = DataWorkspace.ApplicationData.Regions_SingleOrDefault(1)

        End Sub

        Private itemsControl As System.Windows.Controls.DataGrid = Nothing
        'Private itemWindow As ModalWindowHelper

        'Private Sub Items_ControlAvailable(send As Object, e As ControlAvailableEventArgs)
        '    itemsControl = TryCast(e.Control, System.Windows.Controls.DataGrid)
        'End Sub

        Private Sub SaveItem_Execute()
            mwh.DialogOk()
        End Sub

        Private Sub EditableEmployeesGrid_Activated()
            ' Write your code here.

        End Sub
    End Class

End Namespace
