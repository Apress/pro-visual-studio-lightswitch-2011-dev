﻿
Namespace LightSwitchApplication

    Public Class HomeScreen

        Private Sub Method_Execute()
            ' Write your code here.

            Dim s As String = ShowInputBox("Enter some text", "Title")
            Me.Application.ShowTestScreen("This is a test")
        End Sub

        Private Sub HomeScreen_Activated()
            ' Write your code here.
            Property1 = "Some text"

            Heading1 = "Sample text using the Heading1 font style"
            Heading2 = "Sample text using the Heading2 font style"
            Strong = "Sample text using the Strong font style"
            Emphasis = "Sample text using the Emphasis font style"
            Warning = "Sample text using the Warning font style"
            Note = "Sample text using the Note font style"


      
        End Sub
    End Class

End Namespace
