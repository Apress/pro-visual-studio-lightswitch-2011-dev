﻿
Namespace LightSwitchApplication

    Public Class Application

        Private Sub CustomersListDetail_CanRun(ByRef result As Boolean)
            ' Set result to the desired field value
            'Me.User.


        End Sub




        Private Sub CustomerQueryPermCheck_CanRun(ByRef result As Boolean)
            ' Set result to the desired field value

        End Sub
    End Class

End Namespace
