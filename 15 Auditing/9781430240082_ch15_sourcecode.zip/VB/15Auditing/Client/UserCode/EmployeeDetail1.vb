﻿
Namespace LightSwitchApplication

    Public Class EmployeeDetail1

        Private monitoredEmployee As Employee

        Private Sub Employee_Loaded(succeeded As Boolean)
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Employee)
        End Sub

        Private Sub Employee_Changed()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Employee)
        End Sub

        Private Sub EmployeeDetail1_Saved()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Employee)
        End Sub

        Private Sub EmployeeDetail1_InitializeDataWorkspace(saveChangesTo As System.Collections.Generic.List(Of Microsoft.LightSwitch.IDataService))
            Microsoft.LightSwitch.Threading.Dispatchers.Main.BeginInvoke(
                Sub()
                    AddHandler Me.Details.Properties.Employee.Loader.ExecuteCompleted,
                        AddressOf Me.EmployeeLoaderExecuted
                End Sub)
        End Sub


        Private Sub EmployeeLoaderExecuted(sender As Object, e As Microsoft.LightSwitch.ExecuteCompletedEventArgs)
            ' This event handler will be invoked on the Main Dispatcher everytime the Loader finishes an execution.
            ' Therefore Me.Customer will always be correct since we are accessing the Loader's members on the same Dispatcher.
            If monitoredEmployee IsNot Me.Employee Then
                If monitoredEmployee IsNot Nothing Then
                    RemoveHandler TryCast(monitoredEmployee, INotifyPropertyChanged).PropertyChanged, AddressOf Me.EmployeeChanged
                End If

                monitoredEmployee = Me.Employee
                If monitoredEmployee IsNot Nothing Then
                    AddHandler TryCast(monitoredEmployee, INotifyPropertyChanged).PropertyChanged, AddressOf Me.EmployeeChanged
                End If
            End If


        End Sub

        Private Sub EmployeeChanged(sender As Object, e As PropertyChangedEventArgs)
            ' Handles Customer's Property Change events on UI thread.
            Me.ShowMessageBox("CustomerChanged")


            'Me.Details.Properties.Employee.Loader 

            'Me.e
        End Sub


        Private Sub EmployeeDetail1_Activated()
            ' Write your code here.

        End Sub
    End Class

End Namespace