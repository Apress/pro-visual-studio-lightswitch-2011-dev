﻿
Namespace LightSwitchApplication

    Public Class EditableCustomersGrid

        Private Sub Customers_Loaded(succeeded As Boolean)
            '
            'Me.FindControlInCollection (

            'For Each cust In Customers
            '    Me.FindControlInCollection("IsVetted", cust).IsEnabled = False
            'Next

        End Sub
    End Class

End Namespace
