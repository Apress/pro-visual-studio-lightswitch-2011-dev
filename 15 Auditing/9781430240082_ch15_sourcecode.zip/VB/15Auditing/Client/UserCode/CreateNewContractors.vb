﻿Imports System.Windows.Media

Namespace LightSwitchApplication

    Public Class CreateNewContractors

        Private Sub CreateNewContractors_InitializeDataWorkspace(ByVal saveChangesTo As Global.System.Collections.Generic.List(Of Global.Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Me.ContractorsProperty = New Contractors()
        End Sub

        Private Sub CreateNewContractors_Saved()
            ' Write your code here.
            Me.Close(False)
            Application.Current.ShowDefaultScreen(Me.ContractorsProperty)
        End Sub

        Private Sub CreateNewContractors_Activated()
            ' Write your code here.
            Dim c = Me.FindControl("Surname")

            c.DisplayName = "Wow changed!"

            'c.Description = "I can set a description here!!"

            'c.IsEnabled = False
            'c.IsReadOnly = True

            'Dim a = c.GetProperty("Description")

            ' c.IsVisible = False


            'Me.FindControl("HomePhone").Focus()

            ' Me.FindControlInCollection("HomePhone", ContractorsProperty).Focus()


            AddHandler c.ControlAvailable,
                Sub(sender As Object, e As ControlAvailableEventArgs)
                    Dim textbox = CType(e.Control, System.Windows.Controls.TextBox)
                    textbox.Background = New SolidColorBrush(Colors.Yellow)

                    AddHandler CType(e.Control, System.Windows.Controls.TextBox).KeyUp, AddressOf TextBoxKeyUp

                End Sub

        End Sub


        Private Sub TextBoxKeyUp(sender As Object, e As System.Windows.RoutedEventArgs)
            Dim strTextUpper As String = CType(sender, System.Windows.Controls.TextBox).Text.ToUpper
            Dim selStart As Integer = CType(sender, System.Windows.Controls.TextBox).SelectionStart
            CType(sender, System.Windows.Controls.TextBox).Text = strTextUpper
            CType(sender, System.Windows.Controls.TextBox).SelectionStart = selStart
        End Sub





        Private Sub Hide_Execute()
            ' Write your code here.

            Dim c = Me.FindControl("details")

            c.IsVisible = Not (c.IsVisible)
        End Sub




    End Class

End Namespace