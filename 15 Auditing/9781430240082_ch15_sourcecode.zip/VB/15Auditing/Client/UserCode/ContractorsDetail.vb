﻿
Namespace LightSwitchApplication

    Public Class ContractorsDetail

        Private Sub Contractors_Loaded(succeeded As Boolean)
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Contractors)

            'Me.Application.ShowSearchEmployees()

            ' Dim c = Me.FindControl("s")

            '  c.s()

        End Sub

        Private Sub Contractors_Changed()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Contractors)
        End Sub

        Private Sub ContractorsDetail_Saved()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Contractors)
        End Sub

        Private Sub ContractorsDetail_Saving(ByRef handled As Boolean)
            ' Write your code here.

        End Sub

        Private Sub Contractors_Validate(results As ScreenValidationResultsBuilder)
            ' results.AddPropertyError("<Error-Message>")

        End Sub
    End Class

End Namespace