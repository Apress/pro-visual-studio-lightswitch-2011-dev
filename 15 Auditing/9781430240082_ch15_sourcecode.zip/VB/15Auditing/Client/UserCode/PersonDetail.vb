﻿
Namespace LightSwitchApplication

    Public Class PersonDetail

        Private Sub Person_Loaded(succeeded As Boolean)
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Person)
        End Sub

        Private Sub Person_Changed()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Person)
        End Sub

        Private Sub PersonDetail_Saved()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Person)
        End Sub

    End Class

End Namespace