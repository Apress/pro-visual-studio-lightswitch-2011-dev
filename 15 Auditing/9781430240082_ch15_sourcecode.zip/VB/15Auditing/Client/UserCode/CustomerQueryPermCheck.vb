﻿Imports Microsoft.LightSwitch.Security
Imports Microsoft.LightSwitch.Threading

Namespace LightSwitchApplication

    Public Class CustomerQueryPermCheck

        Private Sub Method_Execute()
            ' Write your code here.

            If Application.User.Name.Contains("\") Then
                Me.ShowMessageBox("contains a slash")
                If System.Windows.Application.Current.IsRunningOutOfBrowser Then

                End If
                'Application.Current.User.AuthenticationType 

                If Application.AuthenticationService.AuthenticationType = AuthenticationType.Windows Then

                End If

            End If

        End Sub

        Private Sub Method_CanExecute(ByRef result As Boolean)
            ' Write your code here.

        End Sub
    End Class

End Namespace
