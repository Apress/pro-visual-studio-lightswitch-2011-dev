﻿Imports Microsoft.LightSwitch.Security
Imports Microsoft.LightSwitch.Threading

'Imports System.Windows.br

Public Class Logout
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        '        Me.Application.a()
    End Sub

End Class