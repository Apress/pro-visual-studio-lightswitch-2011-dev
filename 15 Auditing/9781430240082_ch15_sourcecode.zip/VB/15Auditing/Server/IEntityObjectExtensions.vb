﻿Imports System.Runtime.CompilerServices
Imports System.Text
Imports Microsoft.LightSwitch
Imports Microsoft.LightSwitch.Details
Imports Microsoft.LightSwitch.Security

Namespace Extensions


    Public Module IEntityObjectExtensions

        <Extension()>
        Public Function StorageProperty(Of T As IEntityObject)(
                entityObject As T, name As String
                ) As IEntityStorageProperty

            'Here's how to check that entityObject isn't null
            If entityObject Is Nothing Then
                Throw New ArgumentNullException("entityObject")
            Else
                Return TryCast(
                    entityObject.Details.Properties(name), 
                    IEntityStorageProperty)
            End If

        End Function

        '<Extension()>
        'Public Function TrackedProperties(Of T As IEntityObject)(entityObject As T, Optional excludedProperties As String = " ") As IEnumerable(Of IEntityTrackedProperty)

        '    Dim result As IEnumerable(Of IEntityTrackedProperty) = Nothing
        '    Dim excluded = excludedProperties.ToLower

        '    result = entityObject.Details.Properties.All.OfType(Of IEntityTrackedProperty)().Where(Function(x) excluded.Contains(x.Name) = False)


        '    Return result
        'End Function

        <Extension()>
        Public Function TrackedProperties(Of T As IEntityObject)(
            entityObject As T) As IEnumerable(
                Of IEntityTrackedProperty)

            Return entityObject.Details.Properties.All.OfType(
                Of IEntityTrackedProperty)()

            'You can modify the results of this method to exclude properties
            'The line beneath illustrates how you would exclude the surname property
            'Return entityObject.Details.Properties.All.OfType(Of IEntityTrackedProperty)().Where(Function(x) x.Name.Contains("Surname") = False)

        End Function


        <Extension()>
        Public Sub GetChanges(entityObject As IEntityObject, ByRef oldValues As String, ByRef newValues As String, Optional valuesFormat As String = "{0}: {1}{2}")
            Dim newResults = New StringBuilder
            Dim oldResults = New StringBuilder
            Dim properties =
                entityObject.TrackedProperties()

            For Each p In properties
                Select Case entityObject.Details.EntityState
                    Case EntityState.Added
                        newResults.AppendFormat(valuesFormat, p.Name, p.Value, " " & Environment.NewLine)

                    Case EntityState.Modified
                        If (p.IsChanged = True) Then
                            oldResults.AppendFormat(valuesFormat, p.Name, p.OriginalValue, " " & Environment.NewLine)
                            newResults.AppendFormat(valuesFormat, p.Name, p.Value, " " & Environment.NewLine)
                        End If

                    Case EntityState.Deleted
                        oldResults.AppendFormat(valuesFormat, p.Name, p.Value, " " & Environment.NewLine)
                End Select
            Next

            'trim any trailing white space
            oldValues = oldResults.ToString.TrimEnd(Nothing)
            newValues = newResults.ToString.TrimEnd(Nothing)
        End Sub

        <Extension()>
        Public Sub UpdateFromEntity(Of T As IEntityObject)(entityObject As T, entity As IEntityObject, actioned As DateTime, user As String)
            Dim oldValues = ""
            Dim newValues = ""
            Dim action = entity.Details.EntityState.ToString

            entity.GetChanges(oldValues, newValues)

            With entityObject.Details
                .Properties("Actioned").Value = actioned
                .Properties("Action").Value = action
                .Properties("ActionedBy").Value = user
                .Properties("OldValues").Value = oldValues
                .Properties("NewValues").Value = newValues
            End With
        End Sub

    End Module


End Namespace
