﻿Imports System.Web
Imports Extensions

Namespace LightSwitchApplication

    Public Class ApplicationDataService

        Private Sub SaveChanges_Executing()

            Dim actioned = Now
            Dim actionedBy = Me.Application.User.Name
            For Each entity In Me.Details.GetChanges
                SaveEntityChanges(entity, actioned, actionedBy)
            Next

        End Sub

        Private Sub SaveEntityChanges(
              entity As IEntityObject, actioned As DateTime, actionedBy As String)
            Dim changeRecord = Me.DataWorkspace.ApplicationData.Changes.AddNew

            With changeRecord
                Dim idProperty = entity.StorageProperty("Id")

                .EntityID = CInt(idProperty.Value)
                .EntityName = entity.Details.DisplayName

                changeRecord.UpdateFromEntity(entity, actioned, actionedBy)
            End With
        End Sub

        Private Sub People_Inserting(entity As Person)
            Dim changeRecord = entity.PersonChanges.AddNew()
            changeRecord.UpdateFromEntity(entity, Now, Me.Application.User.ToString)
        End Sub

        Private Sub People_Updating(entity As Person)
            Dim changeRecord = entity.PersonChanges.AddNew()
            changeRecord.UpdateFromEntity(entity, Now, Me.Application.User.ToString)
        End Sub

       
    End Class

End Namespace
