﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Security.Server;
namespace LightSwitchApplication
{
    public partial class ApplicationDataService
    {
        partial void SaveChanges_Executing()
        {
            var changes = this.Details.GetChanges();
            var actioned = DateTime.Now;
            var actionedBy = this.Application.User.Name;

            foreach (var entity in changes.AddedEntities)
            {
                SaveEntityChanges(entity, actioned, actionedBy);
            }

            foreach (var entity in changes.ModifiedEntities)
            {
                SaveEntityChanges(entity, actioned, actionedBy);
            }

            foreach (var entity in changes.DeletedEntities)
            {
                SaveEntityChanges(entity, actioned, actionedBy);
            }

        }


        private void SaveEntityChanges(IEntityObject entity,
            DateTime actioned, string actionedBy, string excludedProperties = "Id")
        {
            var changeRecord = this.DataWorkspace.ApplicationData.Changes.AddNew();

            var idProperty = entity.StorageProperty("Id");

            changeRecord.EntityID = Convert.ToInt32(idProperty.Value);
            changeRecord.EntityName = entity.Details.DisplayName;

            changeRecord.UpdateFromEntity(entity, actioned, actionedBy);
        }

        partial void People_Inserting(Person entity)
        {
            var changeRecord = entity.PersonChanges.AddNew();
            changeRecord.UpdateFromEntity(entity, DateTime.Now, this.Application.User.ToString());
        }

        partial void People_Updating(Person entity)
        {
            var changeRecord = entity.PersonChanges.AddNew();
            changeRecord.UpdateFromEntity(entity, DateTime.Now, this.Application.User.ToString());
        }

    }


}
