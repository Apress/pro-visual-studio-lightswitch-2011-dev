﻿Imports CentralControls

Namespace LightSwitchApplication

    Public Class UserDetail1109

        Private Sub User_Loaded(succeeded As Boolean)
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.User)
            Dim control = Me.FindControl("Id")
            AddHandler control.ControlAvailable, AddressOf Me.webControlAvailable

        End Sub

        Private Sub webControlAvailable(sender As Object, e As ControlAvailableEventArgs)

            DirectCast(e.Control, CentralControls.WebBrowserControl).uri = (
            New Uri("http://lsfaq.com/ProVSExamples/TimeSheetEntry.aspx?UserId=" & UserId.ToString))

        End Sub


        Private Sub User_Changed()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.User)
        End Sub

        Private Sub UserDetail1109_Saved()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.User)
        End Sub

        Private Sub UserDetail1109_Activated()
            ' Write your code here.

        End Sub
    End Class

End Namespace