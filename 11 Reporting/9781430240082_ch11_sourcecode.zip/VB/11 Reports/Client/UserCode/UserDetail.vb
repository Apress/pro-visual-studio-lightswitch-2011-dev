﻿Imports Central.Utilities
Imports System.Windows.Controls

Namespace LightSwitchApplication

    Public Class UserDetail

        Private Sub User_Loaded(succeeded As Boolean)
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.User)
            Dim surnameControl = Me.FindControl("Surname")
            AddHandler surnameControl.ControlAvailable, AddressOf Me.OnSurnameAvailable

            Property1 = "Open the report either using the hyperlink in the details section or the command bar button"

        End Sub

        Private Sub OnSurnameAvailable(sender As Object, e As ControlAvailableEventArgs)

            Dim url = "http://localhost:1419/TimesheetEntry.aspx?UserID=" & User.Id.ToString()
            Dim control = DirectCast(e.Control, HyperlinkButton)
            control.NavigateUri = New Uri(url)
            control.Content = User.Surname

        End Sub

        Private Sub User_Changed()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.User)
        End Sub

        Private Sub UserDetail_Saved()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.User)
        End Sub

        Private Sub ShowReport_Execute()
            ' Write your code here.
            ReportHelper.LaunchUrl(User.Id.ToString())
        End Sub
    End Class

End Namespace