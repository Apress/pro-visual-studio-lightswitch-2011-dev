﻿Imports Central.Utilities

Namespace LightSwitchApplication

    Public Class EditableUsersGrid1106

        Private Sub ShowReport_Execute()
            ' Write your code here.
            ReportHelper.LaunchUrl(Users.SelectedItem.Id.ToString())
        End Sub

    End Class

End Namespace
