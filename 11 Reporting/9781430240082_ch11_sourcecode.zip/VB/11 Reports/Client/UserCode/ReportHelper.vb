﻿Imports System.Runtime.InteropServices.Automation
Imports System.Windows.Browser

Namespace Central.Utilities

    Public Module ReportHelper

        Const TimeSheetReportUrlFormat As String =
            "http://lsfaq.com/ProVSExamples/TimeSheetEntry.aspx?UserId={0}"

        Public Sub LaunchUrl(ByVal userId As String)

            Dim urlPath = String.Format(TimeSheetReportUrlFormat, UserID)

            If AutomationFactory.IsAvailable Then
                Dim shell = AutomationFactory.CreateObject("Shell.Application")
                shell.ShellExecute(urlPath, "", "", "open", 1)
            Else
                HtmlPage.Window.Invoke(urlPath)
            End If

        End Sub

    End Module

End Namespace
