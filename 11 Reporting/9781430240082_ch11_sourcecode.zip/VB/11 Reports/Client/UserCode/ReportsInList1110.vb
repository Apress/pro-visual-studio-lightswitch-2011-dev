﻿Imports CentralControls
Imports System.Windows.Data

Namespace LightSwitchApplication

    Public Class ReportsInList1110

        Private Sub ReportsInList1110_Activated()
            ' Write your code here.
            Dim control = Me.FindControl("Id")
            Dim converter As New String2UriConverter()
            control.SetBinding(
                WebBrowserControl.URIProperty,
                "Value", converter, BindingMode.OneWay)

        End Sub
    End Class

End Namespace
