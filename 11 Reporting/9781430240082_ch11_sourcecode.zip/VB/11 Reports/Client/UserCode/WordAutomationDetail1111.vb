﻿Imports System.Runtime.InteropServices.Automation

Namespace LightSwitchApplication

    Public Class WordAutomationDetail1111

        Private Sub Customer_Loaded(succeeded As Boolean)
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Customer)

            Property1 = "Make sure the file c:\temp\LetterTemplate.dot exists!"
        End Sub

        Private Sub Customer_Changed()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Customer)
        End Sub

        Private Sub WordAutomationDetail1111_Saved()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Customer)
        End Sub

        Private Sub DoWordExport_Execute()
            ' Write your code here.
            If AutomationFactory.IsAvailable Then
                Try
                    Using wordApp = AutomationFactory.CreateObject("Word.Application")
                        Dim wordDoc = wordApp.Documents.Open(
                            "c:\temp\LetterTemplate.dot")
                        wordDoc.Bookmarks("firstname").Range.InsertAfter(
                            Customer.Firstname)
                        wordApp.Visible = True
                    End Using
                Catch ex As Exception
                    Throw New InvalidOperationException("Failed to create customer letter.", ex)
                End Try
            End If

        End Sub


        Private Sub SendToPrinter_Execute()
            ' Write your code here.
            If AutomationFactory.IsAvailable Then
                Try
                    Using wordApp = AutomationFactory.CreateObject("Word.Application")
                        Dim wordDoc = wordApp.Documents.Open(
                            "c:\temp\LetterTemplate.dot")
                        wordDoc.Bookmarks("firstname").Range.InsertAfter(
                            Customer.Firstname)

                        wordApp.PrintOut()
                        wordDoc.Close(0)

                    End Using
                Catch ex As Exception
                    Throw New InvalidOperationException("Failed to create customer letter.", ex)
                End Try
            End If
        End Sub

        Private Sub ExportToWordUsingEmbeddedTemplate_Execute()
            ' Write your code here.

            If AutomationFactory.IsAvailable Then
                Dim resourceInfo = System.Windows.Application.GetResourceStream(
                                        New Uri("LetterTemplate.dot", UriKind.Relative))

                Dim path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\LetterTemplate.dot"

                Dim file = System.IO.File.Create(path)
                file.Close()

                'Write the stream to the file
                Dim stream As System.IO.Stream = resourceInfo.Stream

                Using fileStream = System.IO.File.Open(path,
                                                           System.IO.FileMode.OpenOrCreate,
                                                           System.IO.FileAccess.Write,
                                                           System.IO.FileShare.None)

                    Dim buffer(0 To stream.Length - 1) As Byte
                    stream.Read(buffer, 0, stream.Length)
                    fileStream.Write(buffer, 0, buffer.Length)
                End Using

                Try
                    Using wordApp = AutomationFactory.CreateObject("Word.Application")
                        Dim wordDoc = wordApp.Documents.Open(path)
                        wordDoc.Bookmarks("firstname").Range.InsertAfter(
                            Customer.Firstname)

                         wordApp.Visible = True

                    End Using
                Catch ex As Exception
                    Throw New InvalidOperationException("Failed to create customer letter.", ex)
                End Try


            End If


        End Sub


        Private Sub WordAutomationDetail1111_Activated()
            ' Write your code here.

        End Sub
    End Class

End Namespace