﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;

namespace LightSwitchApplication
{
    public partial class UserDetail1109
    {
        partial void User_Loaded(bool succeeded)
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.User);

            var ctrl = this.FindControl("Id");
            ctrl.ControlAvailable += this.OnSurnameAvailable;

        }

        private void OnSurnameAvailable(object sender, ControlAvailableEventArgs e)
        {
            if (UserId  != null)
            {
                var url = "http://lsfaq.com/ProVSExamples/TimesheetEntry.aspx?UserID=" + UserId.ToString();
                var control = (CentralControlsCS.WebBrowserControl)e.Control;
                //control.Navigate (new Uri(url));
                control.uri = (new Uri(url));
            }
              
        }


        partial void User_Changed()
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.User);

        }

        partial void UserDetail1109_Saved()
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.User);
        }

     
    }
}