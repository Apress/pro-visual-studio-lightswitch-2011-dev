﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
using PdfSharp;
using PdfSharp.Drawing;
using PdfSharp.Pdf;

namespace LightSwitchApplication
{
    public partial class PDFReport
    {
        partial void DoPDF_Execute()
        {
            // Write your code here.
    Microsoft.LightSwitch.Threading.Dispatchers.Main.BeginInvoke(() =>
    {
        PdfDocument document = new PdfDocument();
        document.Info.Title = "Dispatch Notice";

        // Create an empty page
        PdfPage page = document.AddPage();

        // Get an XGraphics object for drawing
        XGraphics gfx = XGraphics.FromPdfPage(page);

        // Create a font
        XFont fontHeader1 = new XFont("Verdana", 18, XFontStyle.Bold);
        XFont fontHeader2 = new XFont("Verdana", 14, XFontStyle.Bold);
        XFont fontNormal = new XFont("Verdana", 12, XFontStyle.Regular );

        // Create the report text
        gfx.DrawString ("ShipperCentral Dispatch" , fontHeader1,  
        XBrushes.Black, new XRect(5, 5, 200, 18), XStringFormats.TopCenter );

        gfx.DrawString ("Thank you for shopping......" , fontNormal ,   
            XBrushes.Black, new XRect(5, 18, 200, 18), XStringFormats.TopLeft );

        gfx.DrawString ("Order Number: " + "5", fontHeader2,   
        XBrushes.Black, new XRect(5, 32, 200, 18), XStringFormats.TopLeft );

        //.... create other Elements here

        // Save the document here
        string myDocuments = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        document.Save(myDocuments + "\\DispatchNotice.pdf");

        this.ShowMessageBox(@"A PDF Report has been saved into My Documents\DispatchNotice.pdf");

    });

        }
    }
}
