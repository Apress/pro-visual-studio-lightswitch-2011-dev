﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices.Automation;
using System.Windows.Browser;

namespace Central.Utilities
{

    public static class ReportHelper
    {

        private static string TimeSheetReportUrlFormat = @"http://lsfaq.com/ProVSExamples/TimeSheetEntry.aspx?UserId={0}";


        public static void LaunchUrl(string userId)
        {

            string urlPath = string.Format(TimeSheetReportUrlFormat, userId);

            if (AutomationFactory.IsAvailable)
            {
                var shell = AutomationFactory.CreateObject("Shell.Application");
                shell.ShellExecute(urlPath, "", "", "open", 1);
            }
            else
            {
                HtmlPage.Window.Invoke(urlPath);
            }

        }
    }
}
