﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
using Central.Utilities;

namespace LightSwitchApplication
{
    public partial class UserDetail
    {
        partial void User_Loaded(bool succeeded)
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.User);
        }

        partial void User_Changed()
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.User);
        }

        partial void UserDetail_Saved()
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.User);
        }

        partial void ShowReport_Execute()
        {
            // Write your code here.
            ReportHelper.LaunchUrl(User.Id.ToString());

        }
    }
}