﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
using Central.Utilities;

namespace LightSwitchApplication
{
    public partial class EditableUsersGrid1106
    {
        partial void ShowReport_Execute()
        {
            // Write your code here.
            ReportHelper.LaunchUrl(Users.SelectedItem.Id.ToString());

        }
    }
}
