﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
using System.Runtime.InteropServices.Automation;

namespace LightSwitchApplication
{
    public partial class WordAutomationDetail1111
    {
        partial void User_Loaded(bool succeeded)
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.User);
            Property1 = @"Make sure the file c:\temp\LetterTemplate.dot exists!";

        }

        partial void User_Changed()
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.User);
        }

        partial void WordAutomationDetail1111_Saved()
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.User);
        }

        partial void DoWordExport_Execute()
        {
            // Write your code here.
            if (AutomationFactory.IsAvailable)
            {
                try
                {
                    using (var wordApp = AutomationFactory.CreateObject("Word.Application"))
                    {
                        dynamic wordDoc = wordApp.Documents.Open(
                           @"c:\temp\LetterTemplate.dot");
                        wordDoc.Bookmarks("firstname").Range.InsertAfter(
                           User.Firstname);
                        wordApp.Visible = true;
                    }
                }
                catch (Exception ex)
                {
                    throw new InvalidOperationException("Failed to create customer letter.", ex);
                }
            }

        }

        partial void ExportToWordUsingEmbeddedTemplate_Execute()
        {
            // Write your code here.

            if (AutomationFactory.IsAvailable)
            {
                var resourceInfo = System.Windows.Application.GetResourceStream(new Uri("LetterTemplate.dot", UriKind.Relative));

                dynamic path = Environment.GetFolderPath(
                    Environment.SpecialFolder.MyDocuments) + "\\LetterTemplate.dot";

                dynamic file = System.IO.File.Create(path);
                file.Close();

                //Write the stream to the file
                System.IO.Stream stream = resourceInfo.Stream;

                using (var fileStream = System.IO.File.Open
                (path, System.IO.FileMode.OpenOrCreate, System.IO.FileAccess.Write, System.IO.FileShare.None))
                {

                    byte[] buffer = new byte[stream.Length];
                    stream.Read(buffer, 0, (int)stream.Length);
                    fileStream.Write(buffer, 0, buffer.Length);
                }

                try
                {
                    using (var wordApp = AutomationFactory.CreateObject("Word.Application"))
                    {
                        dynamic wordDoc = wordApp.Documents.Open(path);
                        wordDoc.Bookmarks("firstname").Range.InsertAfter(
                           User.Firstname);
                        wordApp.Visible = true;
                    }
                }
                catch (Exception ex)
                {
                    throw new InvalidOperationException("Failed to create customer letter.", ex);
                }

            }
 


        }

        partial void SendToPrinter_Execute()
        {
            // Write your code here.
            // Write your code here.
            if (AutomationFactory.IsAvailable)
            {
                try
                {
                    using (var wordApp = AutomationFactory.CreateObject("Word.Application"))
                    {
                        dynamic wordDoc = wordApp.Documents.Open(
                           @"c:\temp\LetterTemplate.dot");
                        wordDoc.Bookmarks("firstname").Range.InsertAfter(
                           User.Firstname);
                        //wordApp.Visible = true;
                        wordApp.PrintOut();
                        wordDoc.Close(0);

                    }
                }
                catch (Exception ex)
                {
                    throw new InvalidOperationException("Failed to create customer letter.", ex);
                }
            }

        }
    }
}