﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
using System.Runtime.InteropServices.Automation;
using System.Reflection;

namespace LightSwitchApplication
{
    public partial class WordMailMerge1114
    {

        dynamic wordApp;
        dynamic wordDoc;
        Object missingValue = System.Reflection.Missing.Value;

        // Here are the values of the WdMailMergeDestination Enum
        const int wdSendToNewDocument = 0;
        const int wdSendToPrinter = 1;
        const int wdSendToEmail = 2;
        const int wdSendToFax = 3;


        private void CreateMailMergeDataFile()
        {
            dynamic wordDataDoc;
            Object fileName = @"\\Fileserver\Documents\DataDoc.doc";
            Object header = "First_Name, Last_Name, Title, Address";

            wordDoc.MailMerge.CreateDataSource(ref fileName, ref missingValue,
                ref missingValue, ref header);

            // Open the data document to insert data.
            wordDataDoc = wordApp.Documents.Open(ref fileName);

            // Create the header items
            for (int iCount = 1; iCount <= 2; iCount++)
            {
                wordDataDoc.Tables[1].Rows.Add(ref missingValue);
            }

            // Loop through the customer screen collection
            int rowCount = 2;
            foreach (Customer c in Customers)
            {
                FillRow(wordDataDoc, rowCount, c.Firstname, c.Surname, c.Title, c.Address);
                rowCount++;
            }

            // Save and close the file.
            wordDataDoc.Save();
            wordDataDoc.Close(false, ref missingValue, ref missingValue);

        }

        private void FillRow(dynamic wordDoc, int Row, string Text1,
            string Text2, string Text3, string Text4)
        {
            if (Row > wordDoc.Tables[1].Rows.Count)
            {
                wordDoc.Tables[1].Rows.Add();
            }

            // Insert the data into the table.
            wordDoc.Tables[1].Cell(Row, 1).Range.InsertAfter(Text1);
            wordDoc.Tables[1].Cell(Row, 2).Range.InsertAfter(Text2);
            wordDoc.Tables[1].Cell(Row, 3).Range.InsertAfter(Text3);
            wordDoc.Tables[1].Cell(Row, 4).Range.InsertAfter(Text4);
        }


        partial void DoMailMerge_Execute()
        {
            // Write your code here.

            dynamic wordMailMerge;
            dynamic wordMergeFields;

            // Create an instance of Word  and make it visible.
            wordApp = AutomationFactory.CreateObject("Word.Application");
            wordApp.Visible = true;

            // Open the template file
            wordDoc = wordApp.Documents.Open(@"c:\temp\MailMergeTemplate.dot");
            wordDoc.Select();

            wordMailMerge = wordDoc.MailMerge;

            // Create a MailMerge Data file.
            CreateMailMergeDataFile();

            wordMergeFields = wordMailMerge.Fields;
            wordMailMerge.Destination = wdSendToNewDocument;

            wordMailMerge.Execute(false);

            // Close the original form document.
            wordDoc.Saved = true;
            wordDoc.Close(false, ref missingValue, ref missingValue);

            // Release References.
            wordMailMerge = null;
            wordMergeFields = null;
            wordDoc = null;
            wordApp = null;


        }

        partial void DoMailMergeWithoutTemplate_Execute()
        {
            // Write your code here.

            dynamic wordMailMerge;
            dynamic wordMergeFields;
            dynamic wordSelection;

            // Create an instance of Word  and make it visible.
            wordApp = AutomationFactory.CreateObject("Word.Application");
            wordApp.Visible = true;

            // Create a new file rather than open it from a template 
            wordDoc = wordApp.Documents.Add();

            wordSelection = wordApp.Selection;
            wordMailMerge = wordDoc.MailMerge;

            // Create a MailMerge Data file.
            CreateMailMergeDataFile();

            wordMergeFields = wordMailMerge.Fields;

            // Type the text 'Dear' and add the 'First_Name' merge field
            wordSelection.TypeText("Dear ");
            wordMergeFields.Add(wordSelection.Range, "First_Name");
            wordSelection.TypeText(",");
            // programatically write the rest of the document here....

            // Perform mail merge.
            wordMailMerge.Destination = 0;
            wordMailMerge.Execute(false);

            // Release References.
            wordMailMerge = null;
            wordMergeFields = null;
            wordDoc = null;
            wordApp = null;

        }

        partial void WordMailMerge1114_Activated()
        {
            // Write your code here.
            Property1 = @"The DoMailMerge button creates a word document using the file c:\temp\MailMergeTemplate.dot";
        }

    
    
    }
}
