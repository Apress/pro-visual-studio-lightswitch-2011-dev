﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
using CentralControlsCS;
using System.Windows.Data;
namespace LightSwitchApplication
{
    public partial class ReportsInList1110
    {
        partial void ReportsInList1110_Activated()
        {
            // Write your code here.

            var control = this.FindControl("Id");
            String2UriConverter converter = new String2UriConverter();
            control.SetBinding(
                WebBrowserControl.URIProperty,
                "Value", converter, BindingMode.OneWay);
        }
    }

    public class String2UriConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter,
            System.Globalization.CultureInfo culture)
        {
            if (value != null)
            {
                return new Uri(@"http://lsfaq.com/ProVSExamples/TimesheetEntry.aspx?UserID=" + value.ToString());
            }
            else
            {
                return new Uri(@"http://lsfaq.com/ProVSExamples/TimesheetEntry.aspx");
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter,
            System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

}
