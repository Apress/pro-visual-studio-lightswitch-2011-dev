﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
using System.Runtime.InteropServices.Automation;

namespace LightSwitchApplication
{
    public partial class MailToLinkSendEmail
    {
        partial void SendEmailViaHyperlink_Execute()
        {
            // Write your code here.
            SendEmailByHyperlink(ToEmail, SubjectText, BodyText);
        }

    public static void SendEmailByHyperlink(string toAddress, string subject, string body)
    {
        subject = Uri.EscapeDataString(subject);
        body = Uri.EscapeDataString(body);
  
        string url = string.Format("mailto:{0}?subject={1}&body={2}", toAddress, subject, body);
        Uri uri = new Uri(url);

        if (AutomationFactory.IsAvailable)
        {
            var shell = AutomationFactory.CreateObject("Shell.Application");
            shell.ShellExecute(url);
        }else{		
             Microsoft.LightSwitch.Threading.Dispatchers.Main.BeginInvoke(() =>{
                 System.Windows.Browser.HtmlPage.Window.Navigate(uri, "_blank");
             });
        } 
    }

    
    }
}
