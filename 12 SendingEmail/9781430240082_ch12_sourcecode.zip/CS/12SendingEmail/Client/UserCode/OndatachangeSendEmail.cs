﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
namespace LightSwitchApplication
{
    public partial class OndatachangeSendEmail
    {
        partial void OndatachangeSendEmail_Activated()
        {
            // Write your code here.
            Property1 = "Create an order (save it) and then modify it. An email will be sent when the order record is modified.";

        }
    }
}
