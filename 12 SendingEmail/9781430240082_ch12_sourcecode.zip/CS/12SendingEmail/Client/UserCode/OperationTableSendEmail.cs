﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
using Microsoft.LightSwitch.Threading;
using System.Windows.Controls;
namespace LightSwitchApplication
{
    public partial class OperationTableSendEmail
    {
        partial void SendEmail_Execute()
        {
            // Write your code here.
            EmailOperation newEmail = DataWorkspace.ApplicationData.EmailOperations.AddNew();

            newEmail.RecipientEmail = "tim.leung@hotmail.com";
            newEmail.SenderEmail = ToEmail ;
            newEmail.Subject = SubjectText ;
            newEmail.Body = BodyText ;

            DataWorkspace.ApplicationData.SaveChanges();

            //Uncomment the line beneath if you want to keep an audit
            //newEmail.Delete();
            DataWorkspace.ApplicationData.SaveChanges();

        }

        partial void SendMailWithAttachment_Execute()
        {
            // Write your code here.
                Dispatchers.Main.Invoke(() =>
                {
                OpenFileDialog dlg = new OpenFileDialog();
                if (dlg.ShowDialog().GetValueOrDefault(false)  == true)
                { 
                    byte[] data;
                    string fileName;
                    using (FileStream stream = dlg.File.OpenRead())
                    {
                        data = new byte[stream.Length];
                        stream.Read(data, 0, data.Length);
                        fileName = dlg.File.Name;
                    }
 
                    //send the email here
                    this.Details.Dispatcher.BeginInvoke(() =>
                    {
                        using (var dw = new DataWorkspace())
                        {
                            EmailOperation newEmail = dw.ApplicationData.EmailOperations.AddNew();
                            newEmail.RecipientEmail = "tim.leung@hotmail.com";
                            newEmail.SenderEmail = ToEmail;
                            newEmail.Body = BodyText ;
                            newEmail.Subject = SubjectText;
                            newEmail.Attachment = data;
                            newEmail.AttachmentFileName = fileName ;

                            try
                            {
                                dw.ApplicationData.SaveChanges();
                                //write code here to delete the newEmail record here if required…	
                            }
                            catch (Exception ex)
                            {
                                this.ShowMessageBox(ex.Message);
                            }
                        }
                    });
                }
            });  

        }
    }
}
