﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Security.Server;
using System.Net.Mail;
using Central.Utilities;

namespace LightSwitchApplication
{
    public partial class ApplicationDataService
    {
        partial void Orders_Updating(Order entity)
        {

            MailMessage message = new MailMessage();
            message.From = new MailAddress("tim.leung@hotmail.com");
            message.To.Add(entity.Customer.Email);                    
            message.Subject = "Order Updated";
            message.Body = "The status of your order has changed";
            SmtpClient client = new SmtpClient(">relay.yourMailServer.net", 25);
            //Set the details below if you need to send credentials
            //client.Credentials = new System.Net.NetworkCredential("yourusername", "yourpassword");
            //client.UseDefaultCredentials = false;
            client.Send(message);        
        }

        partial void EmailOperations_Inserting(EmailOperation entity)
        {
            SmtpMailHelper.SendMail(
              entity.SenderEmail,
              entity.RecipientEmail,
              entity.Subject,
              entity.Body);

           
        }

     
    }
}
