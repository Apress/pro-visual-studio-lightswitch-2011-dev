﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Mail;
using System.Configuration;

namespace Central.Utilities
{

    public static class SmtpMailHelper
    {
        //private static readonly string SMTPServer = ConfigurationSettings.AppSettings["SMTPServer"];
        //private static readonly string SMTPUserId = ConfigurationSettings.AppSettings["SMTPUserId"];
        //private static readonly string SMTPPassword = ConfigurationSettings.AppSettings["SMTPPassword"];
        //private static readonly int SMTPPort = int.Parse(ConfigurationSettings.AppSettings["SMTPPort"]);

        private static readonly string SMTPServer = ">relay.yourMailServer.net";
        private static readonly int SMTPPort = 25;


        public static void SendMail(string sendFrom, string sendTo, string subject, string body)
        {
            MailAddress fromAddress = new MailAddress(sendFrom);
            MailAddress toAddress = new MailAddress(sendTo);
            MailMessage mail = new MailMessage();

            mail.From = fromAddress;
            mail.To.Add(toAddress);
            mail.Subject = subject;

            if (body.ToLower().Contains("<html>"))
            {
                mail.IsBodyHtml = true;
            }
            mail.Body = body;
            SmtpClient smtp = new SmtpClient(SMTPServer, SMTPPort);
            //add credentials here if required
            //smtp.Credentials = new NetworkCredential(SMTPUserId, SMTPPassword);
            smtp.Send(mail);
        }
    }
}
