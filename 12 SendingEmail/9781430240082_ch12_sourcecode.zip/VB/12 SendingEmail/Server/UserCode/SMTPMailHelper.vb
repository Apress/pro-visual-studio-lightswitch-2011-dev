﻿Imports System.Net
Imports System.Net.Mail
Imports System.Configuration
Imports System.IO

Namespace Central.Utilities

    Public Module SmtpMailHelper
        Private ReadOnly SMTPServer As String = My.Settings.SMTPServer
        Private ReadOnly SMTPUserId As String = My.Settings.SMTPUserId
        Private ReadOnly SMTPPassword As String = My.Settings.SMTPPassword
        Private ReadOnly SMTPPort As Integer = My.Settings.SMTPPort

        Public Sub SendMail(ByVal sendFrom As String,
                                   ByVal sendTo As String,
                                   ByVal subject As String,
                                   ByVal body As String)
            Dim fromAddress = New MailAddress(sendFrom)
            Dim toAddress = New MailAddress(sendTo)
            Dim mail As New MailMessage

            With mail
                .From = fromAddress
                .To.Add(toAddress)
                .Subject = subject
                If body.ToLower().Contains("<html>") Then
                    .IsBodyHtml = True
                End If
                .Body = body
            End With

            Dim smtp As New SmtpClient(SMTPServer, SMTPPort)
            'add credentials here if required
            'smtp.Credentials = New NetworkCredential(SMTPUserId, SMTPPassword)
            smtp.Send(mail)
        End Sub


        Public Sub SendMail(sendFrom As String,
            sendTo As String,
            subject As String,
            body As String,
            attachment As Byte(),
            filename As String)

            Dim fromAddress As New MailAddress(sendFrom)
            Dim toAddress As New MailAddress(sendTo)
            Dim mail As New MailMessage()

            mail.From = fromAddress
            mail.To.Add(toAddress)
            mail.Subject = subject
            mail.Body = body

            If attachment IsNot Nothing AndAlso Not String.IsNullOrEmpty(filename) Then
                Using ms As New MemoryStream(attachment)
                    mail.Attachments.Add(New Attachment(ms, filename))
                    Dim smtp As New SmtpClient(SMTPServer, SMTPPort)
                    smtp.Send(mail)
                End Using
            End If

        End Sub


    End Module

End Namespace
