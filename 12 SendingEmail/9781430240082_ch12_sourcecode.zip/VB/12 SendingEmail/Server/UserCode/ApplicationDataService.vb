﻿Imports System.Net.Mail
Imports Central.Utilities

Namespace LightSwitchApplication

    Public Class ApplicationDataService


        Private Sub Orders_Updating(entity As Order)
            Dim message As New MailMessage()

            message.From = New MailAddress("admin@shippercentral.co.uk")
            message.To.Add(entity.Customer.Email)
            message.Subject = "Order Updated"
            message.Body = "The status of your order has changed. Order ID " & entity.Id
            Dim client As New SmtpClient("yourmailserver.net", 25)

            'Set the details below if you need to send credentials
            'client.Credentials = new System.Net.NetworkCredential("yourUsername", "yourPassword")
            'client.UseDefaultCredentials = false
            client.Send(message)

        End Sub

        Private Sub EmailOperations_Inserting(entity As EmailOperation)

            SmtpMailHelper.SendMail(
                entity.SenderEmail,
                entity.RecipientEmail,
                entity.Subject,
                entity.Body)

            'We’ve sent the email but don’t actually want to save it in the database
            'entity.Details.DiscardChanges()

        End Sub

    End Class

End Namespace
