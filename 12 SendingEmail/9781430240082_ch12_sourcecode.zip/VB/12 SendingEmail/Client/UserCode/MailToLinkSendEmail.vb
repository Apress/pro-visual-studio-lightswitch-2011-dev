﻿Imports System.Runtime.InteropServices.Automation

Namespace LightSwitchApplication

    Public Class MailToLinkSendEmail

        Private Sub SendEmailViaHyperlink_Execute()
            ' Write your code here.
            SendEmailByHyperlink(ToEmail, SubjectText, BodyText)
        End Sub


        Public Sub SendEmailByHyperlink(
              ByVal toAddress As String,
              ByVal subject As String,
              ByVal body As String
            )

            subject = System.Uri.EscapeDataString(subject)
            body = System.Uri.EscapeDataString(body)

            Dim url As String = String.Format(
                "mailto:{0}?subject={1}&body={2}", toAddress, subject, body)
            Dim uri As Uri = New Uri(url)

            If AutomationFactory.IsAvailable Then
                Dim shell = AutomationFactory.CreateObject("Shell.Application")
                'shell.ShellExecute(url) if Option Strict is Off
                CompilerServices.Versioned.CallByName(shell, "ShellExecute", CallType.Method, url)
            Else
                Microsoft.LightSwitch.Threading.Dispatchers.Main.BeginInvoke(
                    Sub()
                        System.Windows.Browser.HtmlPage.Window.Navigate(uri, "_blank")
                    End Sub)
            End If
        End Sub

    End Class

End Namespace
