﻿Imports Microsoft.LightSwitch.Threading
Imports System.Windows.Controls


Namespace LightSwitchApplication

    Public Class OperationTableSendEmail

        Private Sub SendEmail_Execute()
            ' Write your code here.
            Using tempWorkspace As New DataWorkspace()
                Dim newEmail = tempWorkspace.ApplicationData.EmailOperations.AddNew()
                With newEmail
                    .RecipientEmail = ToEmail
                    .SenderEmail = "admin@shippercentral.co.uk"
                    .Subject = "The email subject goes here"
                    .Body = "The email body goes here"
                End With

                Try
                    tempWorkspace.ApplicationData.SaveChanges()

                    ' If you want, you can write some code here to create a record in an audit table
                    newEmail.Delete()
                    tempWorkspace.ApplicationData.SaveChanges()

                Catch ex As Exception
                    ShowMessageBox(ex.Message)
                End Try

            End Using


        End Sub

        Private Sub SendMailWithAttachment_Execute()
            ' Write your code here.
            Dispatchers.Main.Invoke(
                Sub()
                    Dim dlg As New OpenFileDialog()
                    If dlg.ShowDialog().GetValueOrDefault(False) = True Then
                        Dim data As Byte()
                        Using stream As FileStream = dlg.File.OpenRead()
                            data = New Byte(stream.Length - 1) {}
                            stream.Read(data, 0, data.Length)
                        End Using

                        Dim filename = dlg.File.Name

                        'send the email here
                        Me.Details.Dispatcher.BeginInvoke(
                            Sub()

                                Using dw As New DataWorkspace()

                                    Dim newEmail = dw.ApplicationData.EmailOperations.AddNew()
                                    newEmail.RecipientEmail = ToEmail
                                    newEmail.SenderEmail = "admin@shippercentral.co.uk"
                                    newEmail.Body = "The email body goes here"
                                    newEmail.Subject = "The email subject goes here"
                                    newEmail.Attachment = data
                                    newEmail.AttachmentFileName = filename

                                    Try
                                        dw.ApplicationData.SaveChanges()
                                        ' If you want, you can write some code here to 
                                        ' create a record in an audit table
                                        newEmail.Delete()
                                        dw.ApplicationData.SaveChanges()
                                    Catch ex As Exception
                                        ShowMessageBox(ex.Message)
                                    End Try
                                End Using

                            End Sub)

                    End If

                End Sub)

        End Sub

    End Class

End Namespace
