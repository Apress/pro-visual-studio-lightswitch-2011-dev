﻿Imports Central.Utilities
Namespace LightSwitchApplication

    Public Class OutlookSendEmail

        Private Sub SendMailUsingOutlook_Execute()
            ' Write your code here.

            OutlookMailHelper.CreateEmail(
                ToEmail, SubjectText, BodyText)

        End Sub
    End Class

End Namespace
