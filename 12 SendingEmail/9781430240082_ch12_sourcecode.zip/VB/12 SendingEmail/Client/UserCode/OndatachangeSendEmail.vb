﻿
Namespace LightSwitchApplication

    Public Class OndatachangeSendEmail

        Private Sub OndatachangeSendEmail_Activated()
            ' Write your code here.
            Property1 = "Create an order (save it) and then modify it. An email will be sent when the order record is modified."
        End Sub
    End Class

End Namespace
