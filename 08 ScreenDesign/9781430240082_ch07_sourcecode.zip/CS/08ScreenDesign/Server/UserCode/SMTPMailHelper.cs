﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Mail;


namespace Central.Utilities
{

    public static class SmtpMailHelper
    {
        //const string SMTPServer = "relay.yourmailserver.net";

        //mail.plus.net

        const string SMTPServer = "mail3.dotnet-host.com";

        const string SMTPUserId = "lsdemo@lsfaq.com";
        const string SMTPPassword = "lsdemo99";
        const int SMTPPort = 25;

        public static void SendMail(string sendFrom, string sendTo,
            string subject, string body)
        {
      
            MailAddress fromAddress = new MailAddress(sendFrom);
            MailAddress toAddress = new MailAddress(sendTo);
            MailMessage mail = new MailMessage();

            mail.From = fromAddress;
            mail.To.Add(toAddress);
            mail.Subject = subject;

            if (body.ToLower().Contains("<html>"))
            {
                mail.IsBodyHtml = true;
            }
            mail.Body = body;
            SmtpClient smtp = new SmtpClient(SMTPServer, SMTPPort);
            //add credentials here if required
            smtp.Credentials = new NetworkCredential(SMTPUserId, SMTPPassword);
            smtp.Send(mail);
        }
    }

}
