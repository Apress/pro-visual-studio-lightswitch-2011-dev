﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Security.Server;
namespace LightSwitchApplication
{
    public partial class ApplicationDataService
    {
        partial void Customers_Validate(Customer entity, EntitySetValidationResultsBuilder results)
        {

        }


        partial void EmailOperations_Inserting(EmailOperation entity)
        {            
            Central.Utilities.SmtpMailHelper.SendMail (
                entity.SenderEmail,
                entity.RecipientEmail,
                entity.Subject,
                entity.Body);
        }

        partial void Customers_Updating(Customer entity)
        {
            var changeRecord = entity.CustomerChanges.AddNew();
            changeRecord.UpdateFromEntity(
                entity, DateTime.Now, this.Application.User.Name);

        }

        //partial void ProductDocuments_Validate(ProductDocument entity, EntitySetValidationResultsBuilder results)
        //{

        //}
    }
}
