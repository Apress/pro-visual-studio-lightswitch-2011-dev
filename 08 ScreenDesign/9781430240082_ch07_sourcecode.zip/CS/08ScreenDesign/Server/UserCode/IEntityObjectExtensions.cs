﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Details;
using Microsoft.LightSwitch.Security;

namespace Microsoft.LightSwitch
{
    public static class IEntityObjectExtensions
    {
        public static IEntityStorageProperty StorageProperty(
            this IEntityObject entityObject, string name)
        {
            if (entityObject == null)
            {
                throw new ArgumentNullException("entityObject");   
            }
            else
            {
                return (entityObject.Details.Properties[name] as
                    IEntityStorageProperty);
            }
        }

        public static IEnumerable<IEntityTrackedProperty> 
             TrackedProperties(
                 this  IEntityObject entityObject)
        {
            return entityObject.Details.Properties.All()
                .OfType<IEntityTrackedProperty>();

            //You can modify the results of this method to exclude properties
            //Here’s how you would exclude the surname property
            //return entityObject.Details.Properties.All()
            //   .OfType<IEntityTrackedProperty>().Where (
            //    x=> x.Name.Contains ("Surname") == false );
            
        }

        public static void GetChanges(this IEntityObject entityObject
            , ref string oldValues
            , ref string newValues
            , string valuesFormat = "{0}: {1}{2}"
            )
        {
            var newResults = new StringBuilder();
            var oldResults = new StringBuilder();
            var properties = entityObject.TrackedProperties();

            foreach (var p in properties)
            {
                switch (entityObject.Details.EntityState)
                {
                    case EntityState.Added:
                        newResults.AppendFormat(valuesFormat, p.Name, p.Value, Environment.NewLine);

                        break;
                    case EntityState.Modified:
                        if (p.IsChanged == true)
                        {
                            oldResults.AppendFormat(valuesFormat
                                , p.Name, p.OriginalValue, 
                                   Environment.NewLine);
                            newResults.AppendFormat(valuesFormat
                                , p.Name, p.Value, Environment.NewLine);
                        }

                        break;

                    case EntityState.Deleted:
                        oldResults.AppendFormat(valuesFormat
                            , p.Name, p.Value, Environment.NewLine);
                        break;
                }
            }

            //trim any trailing white space
            oldValues = oldResults.ToString().TrimEnd(null);
            newValues = newResults.ToString().TrimEnd(null);
        }

        public static void UpdateFromEntity(
              this IEntityObject entityObject
            , IEntityObject changedEntity 
            , DateTime actioned
            , string user
            ) 
        {
            var oldValues = "";
            var newValues = "";
            var action = changedEntity.Details.EntityState.ToString();

            changedEntity.GetChanges(ref oldValues, ref newValues);

            entityObject.Details.Properties["Actioned"].Value = actioned;
            entityObject.Details.Properties["Action"].Value = action;
            entityObject.Details.Properties["ActionedBy"].Value = user;
            entityObject.Details.Properties["OldValues"].Value = oldValues;
            entityObject.Details.Properties["NewValues"].Value = newValues;
        }
    }
}
