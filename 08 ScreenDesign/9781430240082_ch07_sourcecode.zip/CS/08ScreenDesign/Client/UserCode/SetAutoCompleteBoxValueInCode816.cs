﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
namespace LightSwitchApplication
{
    public partial class SetAutoCompleteBoxValueInCode816
    {
        partial void SetAutoCompleteBoxValue_Execute()
        {
            // Write your code here.
            this.CountryProperty =
    DataWorkspace.ApplicationData.Countries.Where(
        (country) => country.CountryName == " England"
      ).FirstOrDefault();

        }
    }
}
