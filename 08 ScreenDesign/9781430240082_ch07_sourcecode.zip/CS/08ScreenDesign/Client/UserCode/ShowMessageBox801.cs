﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;

namespace LightSwitchApplication
{
    public partial class ShowMessageBox801
    {
        partial void ShowMessageBox801_InitializeDataWorkspace(List<IDataService> saveChangesTo)
        {
            // Write your code here.
            this.CustomerProperty = new Customer();
        }

        partial void ShowMessageBox801_Saved()
        {
            // Write your code here.
            this.Close(false);
            Application.Current.ShowDefaultScreen(this.CustomerProperty);
        }

        partial void DiscardChanges_Execute()
        {
            // Write your code here.
            if (this.ShowMessageBox(
    "Are you sure you want to discard your changes?",
    "Confirm", MessageBoxOption.YesNo) ==
    System.Windows.MessageBoxResult.Yes)
            {
                this.CustomerProperty = new Customer();
                this.ShowMessageBox("The changes have been discarded");
            }

        }
    }
}