﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
using System.ComponentModel;

namespace LightSwitchApplication
{
    public partial class EmployeeDetail
    {
        partial void Employee_Loaded(bool succeeded)
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.Employee);

            // heres how to set the title in code
            this.DisplayName = "My title's been set in code";

            helpDescription = "This screen demonstrates the ShowMessageBox and ShowInputBox commands. It also shows the focus event. Also IContentNofify";

            this.FindControl("Surname").Focus() ;

        }

        partial void Employee_Changed()
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.Employee);
        }

        partial void EmployeeDetail_Saved()
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.Employee);
        }

        partial void DiscardChanges_Execute()
        {
            if (this.ShowMessageBox(
                "Are you sure you want to discard your changes?",
                "Confirm", MessageBoxOption.YesNo) ==
                System.Windows.MessageBoxResult.Yes)
            {
                this.DataWorkspace.ApplicationData.Details.DiscardChanges();
                this.ShowMessageBox("The changes have been discarded");
            }
        }

        partial void EmployeeDetail_Saving(ref bool handled)
        {
            // Write your code here.

        }


        private Employee monitoredEmployee;

        partial void EmployeeDetail_Activated()
        {
            // Write your code here.

        }

        partial void EmployeeDetail_InitializeDataWorkspace(List<IDataService> saveChangesTo)
        {
            // Write your code here.
            Microsoft.LightSwitch.Threading.Dispatchers.Main.BeginInvoke(() =>
            {
                this.Details.Properties.Employee.Loader.ExecuteCompleted += this.EmployeeLoaderExecuted;
            });

        }

        private void EmployeeLoaderExecuted(object sender, Microsoft.LightSwitch.ExecuteCompletedEventArgs e)
        {

            if (monitoredEmployee !=this.Employee)
            {
                if (monitoredEmployee != null)
                {
                    (monitoredEmployee as INotifyPropertyChanged).PropertyChanged -= 
                        this.EmployeeChanged;
                }

                monitoredEmployee = this.Employee;
                if (monitoredEmployee != null)
                {
                    (monitoredEmployee as INotifyPropertyChanged).PropertyChanged += 
                        this.EmployeeChanged;

                    //set the initial state
                    this.FindControl("group").IsVisible =
            monitoredEmployee.SecurityVetted;

                }


            }
        }

        private void EmployeeChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "SecurityVetted")
            {
                //this.FindControl("group").IsVisible =
                //    EmployeeProperty.SecurityVetted.GetValueOrDefault(false);
                this.FindControl("group").IsVisible =
                    monitoredEmployee.SecurityVetted;

            }
        }

    }
}