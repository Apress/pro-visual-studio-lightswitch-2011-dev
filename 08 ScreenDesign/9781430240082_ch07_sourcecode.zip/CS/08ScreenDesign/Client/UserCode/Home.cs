﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
namespace LightSwitchApplication
{
    public partial class Home
    {

        partial void Home_InitializeDataWorkspace(List<IDataService> saveChangesTo)
        {

            //This is the code that sets the screen image by retrieving it from the assembly
            //If you prefer to get the image from a table, use the commented out code    
            ScreenLogo = GetImageFromAssembly("LightSwitchApplication.ScreenLogo.png");
            
            //var appSetting = DataWorkspace.ApplicationData.AppSettings.FirstOrDefault();
            //if (appSetting != null)
            //{
            //    ScreenLogo = appSetting.HomePageLogo;
            //}

            screenTitle = "Welcome to the Pro Visual Studio LightSwitch 2011 Demo Application!";

            helpDescription = @"Welcome to the LightSwitch Pro Sample Application! This application demonstrates some of the concepts that have been covered in the book LightSwitch Pro 2011." + Environment.NewLine + Environment.NewLine
                + "The purpose of this application is to show you some of the things that you can do with LightSwitch." + Environment.NewLine + Environment.NewLine
                + "If you see something you like, you can find out more by looking at the source code. You can download this from:" + Environment.NewLine 
                + "http://www.apress.com/microsoft/net-framework/9781430240082" + Environment.NewLine + Environment.NewLine
                + "For a fuller explaination, you can buy a copy of the book. This contains full details of all the techniques that you'll find in this application.";

            helpDescription3 = "The screen that you're looking at is the Home Screen. This demonstrates how you'd add static text and content onto a screen." + Environment.NewLine + Environment.NewLine
                + "You can also see some examples of how to open screens and pass in parameters by clicking on the links below:";

            linkHelp = "This link opens the employee search search screen and shows you how you'd pass in arguments. It also highlights the use of the InputBox method";

            linkHelp2 = "This link opens the customer search search screen. This shows you how you would filter a search screen using an AutoCompleteBox";

            helpDescription2 = "The items covered in the rest of this application include:" + Environment.NewLine + Environment.NewLine
                + "• Creating combined screens for adding/editing data" + Environment.NewLine
                + "• Uploading and downloding files" + Environment.NewLine
                + "• Working with many-to-many relationships" + Environment.NewLine
                + "• Showing and hiding items on a screen" + Environment.NewLine
                + "• Selecting multiple records" + Environment.NewLine
                + "• Sending Email" + Environment.NewLine
                + "• Auditing changes" + Environment.NewLine
                + "• Viewing Reports" + Environment.NewLine + Environment.NewLine
                + "Feel free to browse the examples by using the left hand navigation menu." ;        
        }


        //private byte[] GetImageByName(string fileName)
        //{
        //    System.Reflection.Assembly assembly = System.Reflection.Assembly.GetExecutingAssembly();
        //    Stream stream = assembly.GetManifestResourceStream(fileName);
        //    return GetStreamAsByteArray(stream);
        //}

        //private byte[] GetStreamAsByteArray(System.IO.Stream stream)
        //{
        //    int streamLength = Convert.ToInt32(stream.Length);
        //    byte[] fileData = new byte[streamLength];
        //    stream.Read(fileData, 0, streamLength);
        //    stream.Close();
        //    return fileData;
        //}

        partial void OpenSearchScreen_Execute()
        {
            // Write your code here.
            this.Application.ShowSearchEmployees();
        }

        partial void OpenSearchScreenParam_Execute()
        {
            // Write your code here.

            string employeeName = this.ShowInputBox("Please enter the name of the employee that you want to search for", "Open Employee Search Screen");

            if (employeeName.Length == 0)
            {
                this.ShowMessageBox("Employee Name must be entered", "Invalid Data", MessageBoxOption.Ok);
            }
            else
            {
                this.Application.ShowSearchEmployeesParameter(employeeName);
            }

        }

        private byte[] GetImageFromAssembly(string fileName)
        {
            System.Reflection.Assembly assembly = System.Reflection.Assembly.GetExecutingAssembly();
            Stream stream = assembly.GetManifestResourceStream(fileName);
            int streamLength = Convert.ToInt32(stream.Length);
            byte[] fileData = new byte[streamLength];
            stream.Read(fileData, 0, streamLength);
            stream.Close();
            return fileData;
        }

        partial void CreateNewProduct_Execute()
        {
            // Write your code here.
            this.Application.ShowProductAddEdit(null);
        }

        partial void OpenSearchScreenACB_Execute()
        {
            // Write your code here.
            this.Application.ShowCustomersSearch();
        }

    }
}
