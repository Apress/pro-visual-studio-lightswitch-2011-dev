﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;

using System.Windows;
namespace LightSwitchApplication
{
    public partial class Detail2
    {
        partial void Method_Execute()
        {
            // Write your code here.
            //this.ShowMessageBox("s");
            //this.DataWorkspace.ApplicationData.Details.v

            var aa = this.cust.Details.ValidationResults.Where(a => a.Severity == ValidationSeverity.Warning);
            var b = aa.Count();

        }

        partial void cust_Validate(ScreenValidationResultsBuilder results)
        {
            // results.AddPropertyError("<Error-Message>");
            var aa = this.cust.Details.ValidationResults.Where(a => a.Severity == ValidationSeverity.Warning );
            var b = aa.Count();


        }

        partial void cust_Changed()
        {
            try
            {
                var aa = this.cust.Details.ValidationResults.Where(a => a.Severity == ValidationSeverity.Warning);
                var b = aa.Count();

            }
            catch (Exception ex)
            {

            }


        }

        partial void Detail2_InitializeDataWorkspace(List<IDataService> saveChangesTo)
        {
            // Write your code here.

            var a = this.FindControl("cust");

            a.ControlAvailable += new EventHandler<ControlAvailableEventArgs>(a_ControlAvailable);

        }

        void a_ControlAvailable(object sender, ControlAvailableEventArgs e)
        {
            //throw new NotImplementedException();
            ((System.Windows.Controls.AutoCompleteBox)e.Control).LostFocus += new RoutedEventHandler(Detail2_LostFocus);
     

        }

        void Detail2_LostFocus(object sender, RoutedEventArgs e)
        {
            //throw new NotImplementedException();
            var aa = this.cust.Details.ValidationResults.Where(a => a.Severity == ValidationSeverity.Warning);
            var b = aa.Count();

        }
    }
}
