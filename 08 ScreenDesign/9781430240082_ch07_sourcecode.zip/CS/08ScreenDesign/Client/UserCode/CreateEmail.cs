﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
using System.Runtime.InteropServices.Automation;
namespace LightSwitchApplication
{
    public partial class CreateEmail
    {


        partial void CreateEmail_Activated()
        {
            screenTitle = "Sending Email";
            helpDescription = "There are a couple of methods that you can use to send email from LightSwitch." + Environment.NewLine + Environment.NewLine +
                                "1 - You can create a link that opens the registered email client on your PC." + Environment.NewLine +
                                "2 - You can write server side code using the methods in System.Net.Mail" + Environment.NewLine + Environment.NewLine +
                                "This screen demonstrates both techniques." ;

            clienth2 = "Client Side Technique";

            linkDescription = "Clink on the link to open up your email client";

            serverh2 = "Server Side Technique";

            serverDesc = "Fill in the controls below and click on the Send Email button to send a messge using server side code."; 
                
        }

        partial void SendEmail_Execute()
        {

            EmailOperation newEmail;

            using (var tempWorkspace = new DataWorkspace())
            {
                newEmail = tempWorkspace.ApplicationData.EmailOperations.AddNew();

                newEmail.RecipientEmail = sendTo;
                newEmail.SenderEmail = "lsdemo@lsfaq.com";
                newEmail.Subject = Subject;
                newEmail.Body = Body;

                try
                {
                    tempWorkspace.ApplicationData.SaveChanges();

                    //If you want, you can write some code here to create a record in an audit table
                    newEmail.Delete();
                    tempWorkspace.ApplicationData.SaveChanges();
                    this.ShowMessageBox("Your email has been sent");
                }
                catch (Exception ex)
                {
                    this.ShowMessageBox(ex.Message);
                }

            }
        }

        partial void SendEmailHyperlink_Execute()
        {
            // Write your code here.
            var subject = Uri.EscapeDataString(Subject );
            var body = Uri.EscapeDataString(Body);

            string url = string.Format("mailto:{0}?subject={1}&body={2}", "tim@lsfaq.com" , "Sending Emails from LightSwitch", "This email was composed in LightSwitch!");
            Uri uri = new Uri(url);

            if (AutomationFactory.IsAvailable)
            {
                var shell = AutomationFactory.CreateObject("Shell.Application");
                shell.ShellExecute(url);
            }
            else
            {
                Microsoft.LightSwitch.Threading.Dispatchers.Main.BeginInvoke(() =>
                {
                    System.Windows.Browser.HtmlPage.Window.Navigate(uri, "_blank");
                });
            }

        }
    }
}
