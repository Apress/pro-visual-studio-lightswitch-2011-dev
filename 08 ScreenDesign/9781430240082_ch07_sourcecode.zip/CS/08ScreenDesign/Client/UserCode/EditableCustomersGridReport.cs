﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
using System.Windows.Data;
using System.Windows.Controls;


namespace LightSwitchApplication
{
    public partial class EditableCustomersGridReport
    {
        partial void EditableCustomersGridReport_Activated()
        {     
            var control = this.FindControl("Surname1");
            blankTarget = "_blank";
            String2UriConverter converter = new String2UriConverter();
            control.SetBinding(HyperlinkButton.ContentProperty,
                "Value", BindingMode.OneWay);
            control.SetBinding(HyperlinkButton.NavigateUriProperty,
                "Details.Entity.Id", converter, BindingMode.OneWay);
            control.SetBinding(HyperlinkButton.TargetNameProperty,
                "Screen.blankTarget", BindingMode.OneWay);

            screenTitle = "Calling Web Reports";
            helpDescription = "If you need to display reports, 2 options that you can use are SQL Server Reporting Services or ASP.NET." + Environment.NewLine + Environment.NewLine
                + "This screen demonstrates how to link data in a LightSwitch screen to an external web report" + Environment.NewLine + Environment.NewLine
                + "Click on one of the customers shown below to open a report in a new window.";
            
        }

        public class String2UriConverter : IValueConverter
        {
            public object Convert(object value, Type targetType, object parameter,
                System.Globalization.CultureInfo culture)
            {
                if (value != null)
                {
                    return new Uri(@"http://www.lsfaq.com/LSReport/CustomerReport.aspx?CustomerId=" + value.ToString());
                }
                else
                {
                    return new Uri(@"");
                }
            }

            public object ConvertBack(object value, Type targetType, object parameter,
                System.Globalization.CultureInfo culture)
            {
                throw new NotImplementedException();
            }

        }

        partial void EditableCustomersGridReport_InitializeDataWorkspace(List<IDataService> saveChangesTo)
        {
            // Write your code here.

        }
    }
}
