﻿using System;
using System.ComponentModel;
using System.Windows.Controls;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Threading;
using Microsoft.LightSwitch.Presentation.Extensions;


namespace LightSwitchApplication.UserCode
{
    public class ModalWindowHelper
    {
        public delegate bool CanCloseFunction();
        private IVisualCollection _collection;
        private string _dialogName;
        private string _entityName;
        private IScreenObject _screen;
        private IContentItemProxy _window;
        private IEntityObject _entity;
        private bool _saveOnClose;

        public ModalWindowHelper(IVisualCollection visualCollection, string dialogName, string entityName = "")
        {
            _collection = visualCollection;
            _dialogName = dialogName;
            _screen = _collection.Screen;
            if (entityName != "")
            {
                _entityName = entityName;
            }
            else
            {
                _entityName = _collection.Details.GetModel().ElementType.Name;
            }
        }

        public void Initialise(bool hasCloseButton = true, bool saveOnClose = false)
        {
            _window = _screen.FindControl(_dialogName);
            _saveOnClose = saveOnClose;

            _window.ControlAvailable +=
                delegate(object sender, ControlAvailableEventArgs e)
                {
                    var window = (ChildWindow)e.Control;
                    window.HasCloseButton = hasCloseButton;

                    window.Closed +=
                        delegate(object sender1, EventArgs e1)
                        {
                            DialogClosed(sender1);
                        };
                };
            
        }


        public bool CanAdd()
        {
            return (_collection.CanAddNew == true);
        }

        public bool CanView()
        {
            return (_collection.SelectedItem != null);
        }

        public void AddEntity()
        {
            _window.DisplayName = string.Format("Add {0}", _entityName);
            _collection.AddNew();
            OpenModalWindow();
        }

        public void ViewEntity()
        {
            _window.DisplayName = string.Format("View {0}", _entityName);
            OpenModalWindow();
        }

        private void OpenModalWindow()
        {
            _entity = _collection.SelectedItem as IEntityObject;
            _screen.OpenModalWindow(_dialogName);
        }

        public void DialogOk()
        {
            if ((_entity != null))
            {
                _screen.CloseModalWindow(_dialogName);
            }
        }

        public void DialogCancel()
        {
            if ((_entity != null))
            {
                _screen.CloseModalWindow(_dialogName);
                DiscardChanges();
            }
        }

        public void DialogClosed(object sender)
        {
            var window = (ChildWindow)sender;
            //if (window.DialogResult.HasValue && _saveOnClose == true)
            //{
            //    _screen.Details.Dispatcher.BeginInvoke(
            //        delegate()
            //        {
            //            _screen.Save();
            //        });
            //}
            //else
            //{
            //    DiscardChanges();
            //}
        }

        private void DiscardChanges()
        {
            if ((_entity != null))
            {
                _entity.Details.DiscardChanges();
            }
        }

    }
}
