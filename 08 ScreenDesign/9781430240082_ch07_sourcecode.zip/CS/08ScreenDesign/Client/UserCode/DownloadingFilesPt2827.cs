﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;


using System.Windows.Controls;
using Microsoft.LightSwitch.Threading;
using System.Runtime.InteropServices.Automation;


namespace LightSwitchApplication
{
    public partial class DownloadingFilesPt2827
    {
        partial void ProductDocument_Loaded(bool succeeded)
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.ProductDocument);
        }

        partial void ProductDocument_Changed()
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.ProductDocument);
        }

        partial void DownloadingFilesPt2827_Saved()
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.ProductDocument);
        }

        partial void SaveFileFromDatabase_Execute()
        {
            Dispatchers.Main.Invoke(() =>
            {
                //Replace ProductDocument with the name of your entity
                System.IO.MemoryStream ms = new System.IO.MemoryStream(ProductDocument.File);

                Dispatchers.Main.Invoke(() =>
                {
                    SaveFileDialog saveDialog = new SaveFileDialog();

                    if (saveDialog.ShowDialog() == true)
                    {
                        using (Stream fileStream = saveDialog.OpenFile())
                        {
                            ms.WriteTo(fileStream);
                        }

                    }

                });
            });

        }

        partial void OpenFileFromDatabase_Execute()
        {
            // Write your code here.
            try
            {
                if ((AutomationFactory.IsAvailable))
                {
                    //this is where we'll save the file
                    string fullFilePath = System.IO.Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                        ProductDocument.FileName);

                    //replace ProductDocument with the name of your file property
                    byte[] fileData = ProductDocument.File.ToArray();

                    if ((fileData != null))
                    {

                        
                        using (FileStream fs =
                            new FileStream(fullFilePath, FileMode.OpenOrCreate, FileAccess.Write))
                        {
                            fs.Write(fileData, 0, fileData.Length);
                            fs.Close();
                        }
                    }

                    dynamic shell = AutomationFactory.CreateObject("Shell.Application");
                    shell.ShellExecute(fullFilePath);
                }

            }
            catch (Exception ex)
            {
                this.ShowMessageBox(ex.ToString());
            }

        }


    }
}