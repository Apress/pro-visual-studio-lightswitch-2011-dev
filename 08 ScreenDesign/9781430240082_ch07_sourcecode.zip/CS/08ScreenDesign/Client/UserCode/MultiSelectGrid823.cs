﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;

using System.Windows.Controls;


namespace LightSwitchApplication
{
    public partial class MultiSelectGrid823
    {

        private DataGrid _datagridControl = null;

        partial void MultiSelectGrid823_InitializeDataWorkspace(List<IDataService> saveChangesTo)
        {
            screenTitle = "Order Status Codes";
            helpDescription = "In more advanced applications, you'll need some way to apply operations to multiple records. This is where a multi-select grid comes in useful." +
                Environment.NewLine + Environment.NewLine
                + "This screen allows you to update the order status setting on multiple records. Use the <ctrl> key to select multiple records. Next, click on the Update Status button to update the records.";
        }

        partial void MultiSelectGrid823_Created()
        {
            //Replace grid with the name of your data grid control
            this.FindControl("grid").ControlAvailable += 
                (object sender, ControlAvailableEventArgs e) =>
            {
                _datagridControl = ((DataGrid)e.Control);
                _datagridControl.SelectionMode = DataGridSelectionMode.Extended;
            };

        }

        partial void UpdateStatuses_Execute()
        {
            //if (this.ShowMessageBox("Are you sure you want to set all selected orders to Shipped?") == System.Windows.MessageBoxResult.Yes)
            //{
            //    var shippedStatus =
            //        DataWorkspace.ApplicationData.OrderStatusSet.Where(
            //        item => item.OrderStatusDescription  == "Shipped").FirstOrDefault();

            //    foreach (Order ord in _datagridControl.SelectedItems)
            //    {
            //        ord.OrderStatus = shippedStatus;
            //    }
            //}

            foreach (Order ord in _datagridControl.SelectedItems)
            {
                ord.OrderStatus = OrderStatusProperty ;
            }

        }

    }
}
