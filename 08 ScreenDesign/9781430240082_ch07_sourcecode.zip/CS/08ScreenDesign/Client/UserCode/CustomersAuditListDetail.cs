﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
namespace LightSwitchApplication
{
    public partial class CustomersAuditListDetail
    {
        partial void CustomersAuditListDetail_Activated()
        {
            screenTitle = "Auditing Data Changes";
            helpDescription = "Auditing allows you to keep a record of any data changes that have been made by users." + Environment.NewLine + Environment.NewLine +
                                "Use this screen to add or edit customers. Any changes that you make are recorded and shown in the Customer Changes DataGrid.";
        }
    }
}
