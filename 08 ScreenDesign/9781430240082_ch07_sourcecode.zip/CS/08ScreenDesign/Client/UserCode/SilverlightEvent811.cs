﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;

namespace LightSwitchApplication
{
    public partial class SilverlightEvent811
    {
        partial void SilverlightEvent811_InitializeDataWorkspace(List<IDataService> saveChangesTo)
        {
            // Write your code here.
            this.CustomerProperty = new Customer();
            this.FindControl("Surname").ControlAvailable += TextBoxAvailable;
        }


        private void TextBoxAvailable(object sender, ControlAvailableEventArgs e)
        {
            ((System.Windows.Controls.TextBox)e.Control).KeyUp += TextBoxKeyUp;
        }

        private void TextBoxKeyUp(object sender, System.Windows.RoutedEventArgs e)
        {
            var textbox = (System.Windows.Controls.TextBox)sender;

            string textUppered = textbox.Text.ToUpper();
            int selStart = textbox.SelectionStart;
            textbox.Text = textUppered;
            textbox.SelectionStart = selStart;
        }


        partial void SilverlightEvent811_Saved()
        {
            // Write your code here.
            this.Close(false);
            Application.Current.ShowDefaultScreen(this.CustomerProperty);
        }

        partial void SilverlightEvent811_Activated()
        {
            // Write your code here.
            Property1 = "Type into the Surname field";
        }
    }
}