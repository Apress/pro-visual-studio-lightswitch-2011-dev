﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;

namespace LightSwitchApplication
{
    public partial class HideShowCtrls808
    {
        partial void HideShowCtrls808_InitializeDataWorkspace(global::System.Collections.Generic.List<global::Microsoft.LightSwitch.IDataService> saveChangesTo)
        {
            // Write your code here.
            this.CustomerProperty = new Customer();
        }

        partial void HideShowCtrls808_Saved()
        {
            // Write your code here.
            this.Close(false);
            Application.Current.ShowDefaultScreen(this.CustomerProperty);
        }

        partial void ToggleVisibility_Execute()
        {
            // Write your code here.
            var rowLayout = this.FindControl("Group");
            rowLayout.IsVisible = !(rowLayout.IsVisible);

        }
    }
}