﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
using System.Windows.Media;
namespace LightSwitchApplication
{
    public partial class ControlAvailable810
    {
        partial void ControlAvailable810_InitializeDataWorkspace(List<IDataService> saveChangesTo)
        {
            // Write your code here.
            this.CustomerProperty = new Customer();

            var control = this.FindControl("Surname");

            control.ControlAvailable +=
              (object sender, ControlAvailableEventArgs e) =>
              {
                  var textbox =
                     (System.Windows.Controls.TextBox)e.Control;
                  textbox.Background = new SolidColorBrush(Colors.Yellow);
              };

        
        }

        partial void ControlAvailable810_Saved()
        {
            // Write your code here.
            this.Close(false);
            Application.Current.ShowDefaultScreen(this.CustomerProperty);
        }
    }
}