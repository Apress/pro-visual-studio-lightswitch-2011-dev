﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
namespace LightSwitchApplication
{
    public partial class CustomersWebBrowser
    {
        partial void CustomersWebBrowser_Activated()
        {
            screenTitle = "Customers - Web Browser Integration";
            helpDescription = "This is an example of how to integrate." + Environment.NewLine + Environment.NewLine; //+
            //"Click on the Security Vetted checkbox to show and hide the security vetting controls." + Environment.NewLine + Environment.NewLine +
            //"The code on this screen shows you how to monitor data changes on the Employee property. When the Employee > SecurityVetted property changes, the code uses the FindControl method to obtain a reference to the group that contains security vetting controls. It then shows or hides the group by setting the visibility property.";

        }
    }
}
