﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;

namespace LightSwitchApplication
{
    public partial class ManyToMany822
    {
        partial void ManyToMany822_InitializeDataWorkspace(List<IDataService> saveChangesTo)
        {
            this.ProductProperty = new Product();
            screenTitle = "Creating a Many-to-Many screen";
            helpDescription = "LightSwitch supports many different types of relationships. However, many-to-many relationships can't be created 'out of the box'. You'll need to manually create a junction table to support these types of relationships." + Environment.NewLine + Environment.NewLine
                + "After creating the underlying data structure, you'll need to design a screen that allows you to work with this data." + Environment.NewLine + Environment.NewLine
                + "This screen allows you to create a new Product and to assign attributes. Each product can be associated with multiple attributes, and each attribute can be associated with multiple products." + Environment.NewLine + Environment.NewLine;
        }

        partial void AddAttribute_Execute()
        {
            if ((Attributes.SelectedItem != null))
            {
                ProductAttribute prodAtt = ProductAttributes1.AddNew() ;
                prodAtt.Product = this.ProductProperty;
                prodAtt.Attribute = Attributes.SelectedItem;
            }
        }

        partial void RemoveAttribute_Execute()
        {
            ProductAttributes1.DeleteSelected();
        }
    
    }
}