﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
namespace LightSwitchApplication
{
    public partial class ProductHome
    {
        partial void ProductHome_InitializeDataWorkspace(List<IDataService> saveChangesTo)
        {
            // Write your code here.

            screenTitle = "Products";
            helpDescription = "The following set of screens demonstrate the combined add/edit." + Environment.NewLine + Environment.NewLine
                + "Combined add/edit screens save you time because you only need to create a single screen for adding and viewing data.";

            addLinkText = "Click here to open the screen in Add mode. The code syntax used is this.Application.ShowProductAddEdit(null)";

        }

        partial void OpenAddScreen_Execute()
        {
            // Write your code here.
            this.Application.ShowProductAddEdit(null);
        }
    }
}
