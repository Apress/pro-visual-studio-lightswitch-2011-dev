﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
namespace LightSwitchApplication
{
    public partial class SearchCustomerSearch
    {
        partial void CustomerSearch_Loaded(bool succeeded)
        {

        }

        partial void SearchCustomerSearch_Created()
        {
            // Write your code here.
            this.CountryProperty =
    DataWorkspace.ApplicationData.Countries.Where(
        (country) => country.CountryName == "England"
      ).FirstOrDefault();


        }

        partial void SearchCustomerSearch_Activated()
        {
            // Write your code here.

        }
    }
}
