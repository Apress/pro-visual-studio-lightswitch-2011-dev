﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;


using System.ComponentModel;

namespace LightSwitchApplication
{
    public partial class PropertyChanged812
    {
        partial void PropertyChanged812_InitializeDataWorkspace(List<IDataService> saveChangesTo)
        {
            // Write your code here.
            this.EmployeeProperty = new Employee();
            screenTitle = "Hide /Show Groups - New Employee";
            helpDescription = "From time to time, you'll need to modify the appearance of your screen based on the data that's entered." + Environment.NewLine + Environment.NewLine +
                                "Click on the Security Vetted checkbox to show and hide the security vetting controls." + Environment.NewLine + Environment.NewLine +
                                "The code on this screen shows you how to monitor data changes on the Employee property. When the Employee > SecurityVetted property changes, the code uses the FindControl method to obtain a reference to the group that contains security vetting controls. It then shows or hides the group by setting the visibility property.";
        }

        partial void PropertyChanged812_Saved()
        {
            // Write your code here.
            this.Close(false);
            Application.Current.ShowDefaultScreen(this.EmployeeProperty);

            //The commented lines beneath are added by LightSwitch  	
            //Delte these lines  	
            //Me.Close(False)
            //Application.Current.ShowDefaultScreen(Me.EmployeeProperty)

            //Now add a line of code to reset the entity	
            this.EmployeeProperty = new Employee();

        }

        partial void PropertyChanged812_Saving(ref bool handled)
        {
            // Write your code here.
            string comment = this.ShowInputBox(
        "Do you want to include any additional comments?",
        "Confirm Save", "");

            if ((comment != null) && comment.Length > 0)
            {
                this.EmployeeProperty.Comment = comment;
            }

        }


        partial void PropertyChanged812_Created()
        {
            // Write your code here.
            Microsoft.LightSwitch.Threading.Dispatchers.Main.BeginInvoke(() =>
            {
                ((INotifyPropertyChanged)this.EmployeeProperty).PropertyChanged +=
                   CustomerFieldChanged;
            });

            //set the initial state
            this.FindControl("group").IsVisible =
    EmployeeProperty.SecurityVetted;

        }


        private void CustomerFieldChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "SecurityVetted")
            {
                this.FindControl("group").IsVisible =
                    EmployeeProperty.SecurityVetted;
            }
        }

        partial void EmployeeProperty_Validate(ScreenValidationResultsBuilder results)
        {
            // results.AddPropertyError("<Error-Message>");

        }

        partial void PropertyChanged812_Activated()
        {
            // Write your code here.

        }


    }
}