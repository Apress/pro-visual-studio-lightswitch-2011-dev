﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
using System.Windows.Media;
namespace LightSwitchApplication
{
    public partial class CreateNewCustomer
    {

        private System.Windows.Controls.TextBox textbox;

        partial void CreateNewCustomer_InitializeDataWorkspace(
List<IDataService> 
            saveChangesTo)
        {
            // Write your code here.
            this.CustomerProperty = new Customer();
            helpDescription = "This demonstrates how to toggle a group, & setting input colours";

            var control = this.FindControl("Surname");
            control.ControlAvailable +=
                (object sender, ControlAvailableEventArgs e) =>
                {
                    textbox =
                        (System.Windows.Controls.TextBox)e.Control;

                    textbox.Background = new SolidColorBrush(Colors.Yellow);

                    ((System.Windows.Controls.TextBox)e.Control).KeyUp += TextBoxKeyUp;

                };



        //    this.FindControl(LIST_CONTROL).ControlAvailable += (
        //object send, ControlAvailableEventArgs e) =>
        //{
        //    itemsControl = e.Control as System.Windows.Controls.DataGrid;
        //};



        }


        private void TextBoxKeyUp(object sender, System.Windows.RoutedEventArgs e)
        {
            var textbox = (System.Windows.Controls.TextBox)sender;

            string textUppered = textbox.Text.ToUpper();
            int selStart = textbox.SelectionStart;
            textbox.Text = textUppered;
            textbox.SelectionStart = selStart;
        }


        partial void CreateNewCustomer_Saved()
        {
            // Write your code here.
            this.Close(false);
            Application.Current.ShowDefaultScreen(this.CustomerProperty);
        }

        partial void ToggleVisibility_Execute()
        {
            // Write your code here.
            var rowLayout = this.FindControl("AddressGroup");
            rowLayout.IsVisible = !(rowLayout.IsVisible);

        }

        partial void CreateNewCustomer_Activated()
        {
            // Write your code here.

        }

        partial void ChangeColor_Execute()
        {
            // Write your code here.
            textbox.Background = new SolidColorBrush(Colors.Green);

        }

        partial void CustomerProperty_Validate(ScreenValidationResultsBuilder results)
        {
            // results.AddPropertyError("<Error-Message>");

        }

        partial void CreateNewCustomer_Saving(ref bool handled)
        {
            // Write your code here.

        }
    }
}