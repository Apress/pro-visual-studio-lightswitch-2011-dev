﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
namespace LightSwitchApplication
{
    public partial class DownloadingFilesPt1827
    {
        partial void DownloadingFilesPt1827_InitializeDataWorkspace(List<IDataService> saveChangesTo)
        {
            // Write your code here.
            screenTitle = "Product Documents";
            helpDescription = "Use this screen to view the product documents that have been uploaded into the database." + Environment.NewLine + Environment.NewLine
                + "From this screen, you'll be able to open the details screen which will allow you to download the documents that have been uploaded.";

        }
    }
}
