﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
namespace LightSwitchApplication
{
    public partial class CheckboxesReadonly809
    {
        partial void CheckboxesReadonly809_Activated()
        {
            // Write your code here.

        }

        partial void Employees_Loaded(bool succeeded)
        {
            foreach (Employee emp in Employees)
            {
                this.FindControlInCollection(
                    "SecurityVetted", emp).IsEnabled = false;
            }

        }
    }
}
