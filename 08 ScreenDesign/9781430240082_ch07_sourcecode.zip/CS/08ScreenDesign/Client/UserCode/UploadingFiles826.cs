﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;

using System.Windows.Controls;
using Microsoft.LightSwitch.Threading;
using System.Runtime.InteropServices.Automation;


namespace LightSwitchApplication
{
    public partial class UploadingFiles826
    {
        partial void UploadingFiles826_InitializeDataWorkspace(List<IDataService> saveChangesTo)
        {
            // Write your code here.
            this.ProductDocumentProperty = new ProductDocument();

            screenTitle = "Uploading Files to the Database";
            helpDescription = "LightSwitch allows you to store binary files in your database." + Environment.NewLine + Environment.NewLine
                                + "This screen shows you how to upload files to a database by using the Silverlight File Open Dialog." + Environment.NewLine + Environment.NewLine
                                + "You might want to prevent users from uploading very large files. This screen also shows you how to validate file sizes by preventing files greater than 256KB from from being uploaded." + Environment.NewLine + Environment.NewLine
                                + "Try uploading a file by clicking on the Upload File button. Make sure to Save afterward" + Environment.NewLine + Environment.NewLine
                            + "After adding a file, the record will open in a details screen. You'll be able to download the file that you've uploaded using this screen.";


            oobWarning = "This sample only works when run as a desktop application." + Environment.NewLine + Environment.NewLine +
                "LightSwitch has detected that COM automation isn't available."; 

            this.FindControl("oobWarning").IsVisible = !AutomationFactory.IsAvailable;

        }


        partial void UploadingFiles826_Saved()
        {
            this.ShowMessageBox("Your document has been successfully uploaded");
        }

        partial void UploadFileToDatabase_Execute()
        {
            // Write your code here.
            Dispatchers.Main.Invoke(() =>
            {
                OpenFileDialog openDialog = new OpenFileDialog();
                openDialog.Filter = "Supported files|*.*";
                //Use this syntax to only allow Word/Excel files
                //opendlg.Filter = "Word Files|*.doc|Excel Files |*.xls"; 

                if (openDialog.ShowDialog() == true)
                {
                    using (System.IO.FileStream fileData = 
                        openDialog.File.OpenRead())
                    {
                        int fileLen = (int)fileData.Length;

                        if ((fileLen > 0))
                        {
                            byte[] fileBArray = new byte[fileLen];
                            fileData.Read(fileBArray, 0, fileLen);
                            fileData.Close();

                            this.ProductDocumentProperty.File = fileBArray;
                            this.ProductDocumentProperty.FileExtension =
                                openDialog.File.Extension.ToString();
                            this.ProductDocumentProperty.FileName = openDialog.File.Name;
                        }
                    }
                }

            });

        }

       
    }
}