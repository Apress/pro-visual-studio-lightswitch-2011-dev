﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
namespace LightSwitchApplication
{
    public partial class EditableProductsGrid
    {
        partial void EditableProductsGrid_InitializeDataWorkspace(List<IDataService> saveChangesTo)
        {
            screenTitle = "Products";
            helpDescription = "Use this screen to view the products that have been added." + Environment.NewLine + Environment.NewLine
                + "From this screen, you'll be able to open the selected in the combined Add/Edit Screen";
            addLinkText = "Click here to open the screen in Add mode. The code syntax that's used is this.Application.ShowProductAddEdit(null)";
        }

        partial void OpenAddScreen_Execute()
        {
            // Write your code here.
            //this.Application.ShowProductAddEdit(null);
        }

    }
}
