﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
namespace LightSwitchApplication
{
    public partial class CreateBaseData
    {
        partial void CreateBaseData_InitializeDataWorkspace(List<IDataService> saveChangesTo)
        {
            screenTitle = "Creating Base Data";
            helpDescription = "When you first deploy your LightSwitch application, your database won't contain any data." + Environment.NewLine + Environment.NewLine
                + "It's useful to have some mechanism to populate your database with 'base data'. This might include country lists or order status codes." + Environment.NewLine + Environment.NewLine                               
                + "The code behind this screen shows you how to create data using code. You'll find this in method CreateData_Execute() in the screen CreateBaseData." + Environment.NewLine + Environment.NewLine
                + "Click on the Create Base Data button to create the sample data.";
        }

        partial void CreateData_Execute()
        {

            using (DataWorkspace tws = new DataWorkspace())
            {

                //create countries here...

                if (tws.ApplicationData.Countries.Where(a => a.CountryName == "England").FirstOrDefault() == null)
                {
                    Country c1 = tws.ApplicationData.Countries.AddNew();
                    c1.CountryName = "England";
                }

                if (tws.ApplicationData.Countries.Where(a => a.CountryName == "Australia").FirstOrDefault() == null)
                {
                    Country c1 = tws.ApplicationData.Countries.AddNew();
                    c1.CountryName = "Australia";
                }

                if (tws.ApplicationData.Countries.Where(a => a.CountryName == "United States").FirstOrDefault() == null)
                {
                    Country c1 = tws.ApplicationData.Countries.AddNew();
                    c1.CountryName = "United States";
                }


                //create order statuses
                if (tws.ApplicationData.OrderStatusSet.Where(a => a.OrderStatusDescription == "Pending").FirstOrDefault() == null)
                {
                    OrderStatus  c1 = tws.ApplicationData.OrderStatusSet.AddNew();
                    c1.OrderStatusDescription = "Pending";
                }

                if (tws.ApplicationData.OrderStatusSet.Where(a => a.OrderStatusDescription == "Shipped").FirstOrDefault() == null)
                {
                    OrderStatus c1 = tws.ApplicationData.OrderStatusSet.AddNew();
                    c1.OrderStatusDescription = "Shipped";
                }

                if (tws.ApplicationData.OrderStatusSet.Where(a => a.OrderStatusDescription == "Cancelled").FirstOrDefault() == null)
                {
                    OrderStatus c1 = tws.ApplicationData.OrderStatusSet.AddNew();
                    c1.OrderStatusDescription = "Cancelled";
                }


                //create attributes
                if (tws.ApplicationData.Attributes.Where(a => a.AttributeName == "Suitable for vegetarians").FirstOrDefault() == null)
                {
                    Attribute c1 = tws.ApplicationData.Attributes.AddNew();
                    c1.AttributeName = "Suitable for vegetarians";
                }

                if (tws.ApplicationData.Attributes.Where(a => a.AttributeName == "Contains Nuts").FirstOrDefault() == null)
                {
                    Attribute c1 = tws.ApplicationData.Attributes.AddNew();
                    c1.AttributeName = "Contains Nuts";
                }

                if (tws.ApplicationData.Attributes.Where(a => a.AttributeName == "Gluten Free").FirstOrDefault() == null)
                {
                    Attribute c1 = tws.ApplicationData.Attributes.AddNew();
                    c1.AttributeName = "Gluten Free";
                }

                if (tws.ApplicationData.Attributes.Where(a => a.AttributeName == "Gluten Free").FirstOrDefault() == null)
                {
                    Attribute c1 = tws.ApplicationData.Attributes.AddNew();
                    c1.AttributeName = "Low in Salt";
                }

                if (tws.ApplicationData.Attributes.Where(a => a.AttributeName == "Gluten Free").FirstOrDefault() == null)
                {
                    Attribute c1 = tws.ApplicationData.Attributes.AddNew();
                    c1.AttributeName = "High in Vitamin C";
                }

                //create employees

                //create customers
                
                //delete customers

                //delete employees


                //if (tws.ApplicationData.Customers.Where(a => a.CreateTime > DateTime.Now ).FirstOrDefault() == null)
                //{
                      
                
                //}



                tws.ApplicationData.SaveChanges();

            }

        }
    }
}
