﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;

using System.ComponentModel;



namespace LightSwitchApplication
{
    public partial class PropertyChangedDetail813
    {

        private Employee monitoredEmployee;

        partial void PropertyChangedDetail813_InitializeDataWorkspace(List<IDataService> saveChangesTo)
        {
            // Write your code here.
            Microsoft.LightSwitch.Threading.Dispatchers.Main.BeginInvoke(() =>
            {
                this.Details.Properties.Employee.Loader.ExecuteCompleted +=
                    this.EmployeeLoaderExecuted;
            });

        }


        private void EmployeeLoaderExecuted(object sender, Microsoft.LightSwitch.ExecuteCompletedEventArgs e)
        {

            if (monitoredEmployee != this.Employee)
            {
                if (monitoredEmployee != null)
                {
                    (monitoredEmployee as INotifyPropertyChanged).PropertyChanged -=
                        this.EmployeeChanged;
                }

                monitoredEmployee = this.Employee;
                if (monitoredEmployee != null)
                {
                    (monitoredEmployee as INotifyPropertyChanged).PropertyChanged +=
                        this.EmployeeChanged;

                    //set the initial visibility here
                    this.FindControl("group").IsVisible =
                       monitoredEmployee.SecurityVetted;
                }
            }
        }

        private void EmployeeChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "SecurityVetted")
            {
                this.FindControl("group").IsVisible =
                    monitoredEmployee.SecurityVetted;
            }
        }

        partial void Employee_Loaded(bool succeeded)
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.Employee);
        }

        partial void Employee_Changed()
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.Employee);
        }

        partial void PropertyChangedDetail813_Saved()
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.Employee);
        }


    }
}