﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
namespace LightSwitchApplication
{
    public partial class SearchEmployeesParameter
    {
        partial void SearchEmployeesParameter_InitializeDataWorkspace(List<IDataService> saveChangesTo)
        {

            screenTitle = "Passing values into Screens ";
            helpDescription = "LightSwitch allows you to pass values into screens using parameters." + Environment.NewLine + Environment.NewLine 
                   + "The value of the search box (shown below) has been set by using an InputBox control on the Home screen.";

        }

        partial void SearchEmployeesParameter_Activated()
        {
            // Write your code here.

        }
    }
}
