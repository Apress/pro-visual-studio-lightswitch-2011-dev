﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
namespace LightSwitchApplication
{
    public partial class EmbeddedImages818
    {
        partial void EmbeddedImages818_Activated()
        {
            // Write your code here.
            ScreenLogo = GetImageFromAssembly("LightSwitchApplication.ScreenLogo.png");
        }


        private byte[] GetImageFromAssembly(string fileName)
        {
            System.Reflection.Assembly assembly =
                System.Reflection.Assembly.GetExecutingAssembly();

            Stream stream =
                assembly.GetManifestResourceStream(fileName);

            int streamLength = Convert.ToInt32(stream.Length);
            byte[] fileData = new byte[streamLength];
            stream.Read(fileData, 0, streamLength);
            stream.Close();
            return fileData;
        }

    
    
    }
}
