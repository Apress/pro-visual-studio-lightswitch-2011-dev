﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;

namespace LightSwitchApplication
{
    public partial class AddEditScreen820
    {
        partial void Product_Loaded(bool succeeded)
        {
            screenTitle = "Combined Add/Edit Screen";
            helpDescription = "LightSwitch includes a New Screen template that allows you to create screens for entering records one at a time. It also includes a Details Screen template that allows you to create screens for viewing records." + Environment.NewLine + Environment.NewLine
                + "If your 'data entry' and 'data viewing' screens are identical, it can be very time consuming to have to create 2 screens for each record type." + Environment.NewLine + Environment.NewLine
                + "Therefore, save time by creating a combination Add and Edit screen.";
       
            this.SetDisplayNameFromEntity(this.ProductProperty);
            SetScreenModeText();
        }

        private void SetScreenModeText()
        {
            if (!this.ProductId.HasValue)
            {
                this.ProductProperty = new Product();
                helpDescription2 = "The screen that you're looking at is in ADD mode. Use this screen to create a record (use the save button in the ribbon bar to save). Once you're done, you'll be able to view the record that you've created using this same identical screen!";
            }
            else
            {
                this.ProductProperty = this.Product;
                helpDescription2 = "The screen that you're looking at is in EDIT mode. It's the same screen that you would have used for creating this record.";
            }
        }

        partial void Product_Changed()
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.ProductProperty);
        }

        partial void AddEditScreen820_Saved()
        {
            // Write your code here.
            this.SetDisplayNameFromEntity(this.Product);
            SetScreenModeText();
        }

    }
}