﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
namespace LightSwitchApplication
{
    public partial class CustomersSearch
    {
        partial void CustomersSearch_InitializeDataWorkspace(List<IDataService> saveChangesTo)
        {
            screenTitle = "Custom Search Screen";

            helpDescription = "This screen demonstrates a custom search screen." + Environment.NewLine + Environment.NewLine
                + "It allows you to filter customers by country by using an AutoCompleteBox." + Environment.NewLine + Environment.NewLine
                + "Notice how the AutoCompleteBox has defaulted to 'England'. You'll find the code that sets this in the CustomersSearch_InitializeDataWorkspace method.";

            //this is how you set a hardcoded Auto Complete Box Value 
            this.CountryProperty =
                DataWorkspace.ApplicationData.Countries.Where(
                    (country) => country.CountryName == "England").FirstOrDefault();
        }

      

    }
}
