﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
using System.Runtime.InteropServices.Automation;
using System.Windows.Controls;


namespace LightSwitchApplication
{
    public partial class CustomersMailMerge
    {

        dynamic wordApp;
        dynamic wordDoc;
        Object missingValue = System.Reflection.Missing.Value;

        // Here are the values of the WdMailMergeDestination Enum
        const int wdSendToNewDocument = 0;
        const int wdSendToPrinter = 1;
        const int wdSendToEmail = 2;
        const int wdSendToFax = 3;

        partial void CustomersMailMerge_Activated()
        {
            // Write your code here.

            screenTitle = "Generating Mail Merges";
            helpDescription = "You can automate Microsoft Office from desktop applications by using COM." + Environment.NewLine + Environment.NewLine +
                                "Automating Microsoft Word therefore provides a method that you can use to produce reports." + Environment.NewLine + Environment.NewLine +
                                "This example shows you how to perform a mail merge using the customers shown in Data Grid beneath." + Environment.NewLine + Environment.NewLine +
                                "Click on the Do Mail Merge Button (shown on the ribbon bar) to perform the mail merge." + Environment.NewLine + Environment.NewLine +
                                "(Note that you'll need to have Microsoft Word installed for this example to work)";


            oobWarning = "This sample only works when run as a desktop application." + Environment.NewLine + Environment.NewLine +
                    "LightSwitch has detected that COM automation isn't available." + Environment.NewLine + 
                    "To run this example, you should try installing and running the desktop version from here:";



            var control = this.FindControl("oobHyperlink");
            control.ControlAvailable += new EventHandler<ControlAvailableEventArgs>(control_ControlAvailable);

            this.FindControl("oobHyperlink").IsVisible = !AutomationFactory.IsAvailable;
            this.FindControl("oobWarning").IsVisible = !AutomationFactory.IsAvailable;

            if (AutomationFactory.IsAvailable)
            {
                CreateWordTemplate();
            }
       
        }

        void control_ControlAvailable(object sender, ControlAvailableEventArgs e)
        {
            HyperlinkButton hl = (HyperlinkButton)e.Control;
            hl.TargetName = "_blank";
            hl.Content = "http://www.lsfaq.com/LSDemoDesktop/";
            hl.NavigateUri = new Uri ("http://www.lsfaq.com/LSDemoDesktop/");
        }

        private void CreateMailMergeDataFile()
        {
            dynamic wordDataDoc;
            //Object fileName = @"\\Fileserver\Documents\DataDoc.doc";
            //Object fileName = @"c:\Fileserver\Documents\DataDoc.doc";

            string fileName = Environment.GetFolderPath(
                Environment.SpecialFolder.MyDocuments) + "\\DataDoc.doc"; 

            Object header = "First_Name, Last_Name, Title, Address";

            wordDoc.MailMerge.CreateDataSource(ref fileName, ref missingValue,
                ref missingValue, ref header);

            // Open the data document to insert data.
            wordDataDoc = wordApp.Documents.Open(ref fileName);

            // Create the header items
            for (int iCount = 1; iCount <= 2; iCount++)
            {
                wordDataDoc.Tables[1].Rows.Add(ref missingValue);
            }

            // Loop through the customer screen collection
            int rowCount = 2;
            foreach (Customer c in Customers)
            {
                FillRow(wordDataDoc, rowCount, c.FirstName, c.Surname, c.Title, c.Address1 );
                rowCount++;               
            }

            // Save and close the file.
            wordDataDoc.Save();
            wordDataDoc.Close(false, ref missingValue, ref missingValue);

        }

        private void FillRow(dynamic wordDoc, int Row, string Text1,
            string Text2, string Text3, string Text4)
        {
            if (Row > wordDoc.Tables[1].Rows.Count)
            {
                wordDoc.Tables[1].Rows.Add();
            }

            // Insert the data into the table.
            wordDoc.Tables[1].Cell(Row, 1).Range.InsertAfter(Text1);
            wordDoc.Tables[1].Cell(Row, 2).Range.InsertAfter(Text2);
            wordDoc.Tables[1].Cell(Row, 3).Range.InsertAfter(Text3);
            wordDoc.Tables[1].Cell(Row, 4).Range.InsertAfter(Text4);
        }

     
        private void CreateWordTemplate()
        {

            dynamic path = Environment.GetFolderPath(
                Environment.SpecialFolder.MyDocuments) + @"\MailMergeTemplate.dot";

            if (!File.Exists(path))
            {
                dynamic file = System.IO.File.Create(path);
                file.Close();

                //Write the stream to the file
                System.Reflection.Assembly assembly = System.Reflection.Assembly.GetExecutingAssembly();
                Stream stream = assembly.GetManifestResourceStream("LightSwitchApplication.MailMergeTemplate.dot");

                using (FileStream fileStream = System.IO.File.Open(path, System.IO.FileMode.OpenOrCreate, System.IO.FileAccess.Write, System.IO.FileShare.None))
                {
                    byte[] buffer = new byte[stream.Length];
                    stream.Read(buffer, 0, (int)stream.Length);
                    fileStream.Write(buffer, 0, buffer.Length);
                }
            }

        }


        partial void DoMailMerge_Execute()
        {
            dynamic wordMailMerge;
            dynamic wordMergeFields;

            // Create an instance of Word  and make it visible.
            wordApp = AutomationFactory.CreateObject("Word.Application");
            wordApp.Visible = true;

            // Open the template file
   
            string templateFile = Environment.GetFolderPath(
                Environment.SpecialFolder.MyDocuments) + @"\MailMergeTemplate.dot";
            wordDoc = wordApp.Documents.Open(templateFile);


            wordDoc.Select();

            wordMailMerge = wordDoc.MailMerge;

            // Create a MailMerge Data file.
            CreateMailMergeDataFile();

            wordMergeFields = wordMailMerge.Fields;
            wordMailMerge.Destination = wdSendToNewDocument;

            wordMailMerge.Execute(false);

            // Close the original form document.
            wordDoc.Saved = true;
            wordDoc.Close(false, ref missingValue, ref missingValue);

            // Release References.
            wordMailMerge = null;
            wordMergeFields = null;
            wordDoc = null;
            wordApp = null;
        }



    
    }
}
