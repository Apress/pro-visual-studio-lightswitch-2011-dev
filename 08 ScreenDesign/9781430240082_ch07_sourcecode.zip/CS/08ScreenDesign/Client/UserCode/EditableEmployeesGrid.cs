﻿using System;
using System.Linq;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using Microsoft.LightSwitch;
using Microsoft.LightSwitch.Framework.Client;
using Microsoft.LightSwitch.Presentation;
using Microsoft.LightSwitch.Presentation.Extensions;
namespace LightSwitchApplication
{
    public partial class EditableEmployeesGrid
    {
        partial void Employees_Loaded(bool succeeded)
        {
            foreach (Employee emp in Employees)
            {
                this.FindControlInCollection(
                    "SecurityVetted", emp).IsEnabled = false;
            }

        }

        partial void EditableEmployeesGrid_InitializeDataWorkspace(List<IDataService> saveChangesTo)
        {
            // Write your code here.

            screenTitle = "Read-Only Screen";
            helpDescription = "Here's an example of a read-only screen." + Environment.NewLine + Environment.NewLine
                + "When creating read-only screens, you'll notice that your checkboxes will still be editable." + Environment.NewLine + Environment.NewLine
                + "This screen contains the workaround code that you'll need to apply to fix this problem.";

        
        }

        partial void EditableEmployeesGrid_Activated()
        {
            // Write your code here.

        }
    }
}
