﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.LightSwitch;
namespace LightSwitchApplication
{
    public partial class ProductDocument
    {
        partial void File_Validate(EntityValidationResultsBuilder results)
        {
            if (this.File != null)
            {
                var sizeInKB = this.File.Length / 1024;
                if (sizeInKB > 256)
                {
                    results.AddPropertyError("File size cannot be > 256kb");
                }
            }
        }
    }
}
