﻿Imports System.Windows.Data
Imports System.Windows.Controls


Namespace LightSwitchApplication

    Public Class HyperlinkControl1108

        Private Sub HyperlinkControl1108_Activated()
            ' Write your code here.
            Dim control = Me.FindControl("Surname")
            blankTarget = "_blank"
            Dim converter As New String2UriConverter()

            control.SetBinding(HyperlinkButton.ContentProperty,
                "Value", BindingMode.OneWay)
            control.SetBinding(HyperlinkButton.NavigateUriProperty,
                "Details.Entity.Id", converter, BindingMode.OneWay)
            control.SetBinding(HyperlinkButton.TargetNameProperty,
                "Screen.blankTarget", BindingMode.OneWay)

        End Sub


    End Class

    Public Class String2UriConverter
        Implements IValueConverter
      
        Public Function Convert(value As Object, targetType As System.Type, parameter As Object, culture As System.Globalization.CultureInfo) As Object Implements System.Windows.Data.IValueConverter.Convert

            If Not value Is Nothing Then
                Return New Uri("http://lsfaq.com/ProVSExamples/TimeSheetEntry.aspx?UserId=" & value.ToString)
            Else
                Return New Uri("http://lsfaq.com/ProVSExamples/TimeSheetEntry.aspx")
            End If

        End Function

        Public Function ConvertBack(value As Object, targetType As System.Type, parameter As Object, culture As System.Globalization.CultureInfo) As Object Implements System.Windows.Data.IValueConverter.ConvertBack
            Throw New NotImplementedException
        End Function

    End Class


End Namespace
