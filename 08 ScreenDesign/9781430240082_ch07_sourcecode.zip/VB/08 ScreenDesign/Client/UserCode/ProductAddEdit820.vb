﻿
Namespace LightSwitchApplication

    Public Class ProductAddEdit820

        Private Sub Product_Loaded(succeeded As Boolean)
            ' Write your code here.
            'Me.SetDisplayNameFromEntity(Me.Product)

            If Not Me.ProductId.HasValue Then
                Me.ProductProperty = New Product()
            Else
                Me.ProductProperty = Me.Product
            End If

            Me.SetDisplayNameFromEntity(Me.ProductProperty)


        End Sub


        Private Sub ProductAddEdit820_Changed()
            Me.SetDisplayNameFromEntity(Me.ProductProperty)
        End Sub

        Private Sub ProductAddEdit820_Saved()
            Me.SetDisplayNameFromEntity(Me.ProductProperty)
        End Sub


        Private Sub ProductAddEdit820_Activated()
            ' Write your code here.

        End Sub
    End Class

End Namespace