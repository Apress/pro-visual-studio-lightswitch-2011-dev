﻿Imports System.Runtime.InteropServices.Automation
Imports System.Reflection


Namespace LightSwitchApplication

    Public Class WordMailMerge1114

        Private wordApp As Object
        Private wordDoc As Object
        Private missingValue As Object = System.Reflection.Missing.Value

        ' Here are the values of the WdMailMergeDestination Enum
        Const wdSendToNewDocument As Integer = 0
        Const wdSendToPrinter As Integer = 1
        Const wdSendToEmail As Integer = 2
        Const wdSendToFax As Integer = 3

        Private Sub CreateMailMergeDataFile()

            Dim wordDataDoc As Object

            Dim fileName = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "DataDoc.doc"
            Dim header As Object = "First_Name, Last_Name, Title, Address"

            wordDoc.MailMerge.CreateDataSource(fileName, missingValue, missingValue, header)

            ' Open the data document to insert data.
            wordDataDoc = wordApp.Documents.Open(fileName)

            ' Create the header items
            For count = 1 To 2
                wordDataDoc.Tables(1).Rows.Add(missingValue)
            Next

            ' Loop through the customer screen collection
            Dim rowCount As Integer = 2
            For Each c As Customer In Customers
                FillRow(wordDataDoc, rowCount, c.Firstname, c.Surname, c.Title, c.Address)
                rowCount += 1
            Next

            ' Save and close the file.
            wordDataDoc.Save()
            wordDataDoc.Close(False)

        End Sub

        Private Sub FillRow(WordDoc As Object, Row As Integer,
                             Text1 As String, Text2 As String, Text3 As String, Text4 As String)

            If Row > WordDoc.Tables(1).Rows.Count Then
                WordDoc.Tables(1).Rows.Add()
            End If

            ' Insert the data into the table.
            WordDoc.Tables(1).Cell(Row, 1).Range.InsertAfter(Text1)
            WordDoc.Tables(1).Cell(Row, 2).Range.InsertAfter(Text2)
            WordDoc.Tables(1).Cell(Row, 3).Range.InsertAfter(Text3)
            WordDoc.Tables(1).Cell(Row, 4).Range.InsertAfter(Text4)

        End Sub

        Private Sub DoMailMerge_CanExecute(ByRef result As Boolean)
            result = AutomationFactory.IsAvailable
        End Sub


        Private Sub DoMailMerge_Execute()
            ' Write your code here.
            Dim wordMailMerge As Object
            Dim wordMergeFields As Object

            ' Create an instance of Word  and make it visible.
            wordApp = AutomationFactory.CreateObject("Word.Application")
            wordApp.Visible = True

            ' Open the template file
            wordDoc = wordApp.Documents.Open("c:\temp\MailMergeTemplate.dot")
            wordDoc.Select()

            wordMailMerge = wordDoc.MailMerge

            ' Create a MailMerge Data file.
            CreateMailMergeDataFile()

            wordMergeFields = wordMailMerge.Fields
            wordMailMerge.Destination = wdSendToNewDocument
            wordMailMerge.Execute(False)

            ' Close the original form document.
            wordDoc.Saved = True
            wordDoc.Close(False, missingValue, missingValue)

            ' Release References.
            wordMailMerge = Nothing
            wordMergeFields = Nothing
            wordDoc = Nothing
            wordApp = Nothing


        End Sub


        Private Sub DoMailMergeWithoutTemplate_Execute()
            ' Write your code here.
            Dim wordMailMerge As Object
            Dim wordMergeFields As Object

            ' Create an instance of Word  and make it visible.
            wordApp = AutomationFactory.CreateObject("Word.Application")
            wordApp.Visible = True

            ' Create a new file rather than open it from a template 
            wordDoc = wordApp.Documents.Add()

            Dim wordSelection As Object
            wordSelection = wordApp.Selection
            wordMailMerge = wordDoc.MailMerge

            ' Create a MailMerge Data file.
            CreateMailMergeDataFile()

            wordMergeFields = wordMailMerge.Fields

            ' Type the text 'Dear' and add the 'First_Name' merge field
            wordSelection.TypeText("Dear ")

            Dim wordRange As Object = wordSelection.Range

            wordMergeFields.Add(wordRange, "First_Name")
            wordSelection.TypeText(",")
            ' programatically write the rest of the document here....

            ' Perform mail merge.
            wordMailMerge.Destination = 0
            wordMailMerge.Execute(False)

            ' Close the original form document.
            wordDoc.Saved = True
            wordDoc.Close(False, missingValue, missingValue)

            ' Release References.
            wordMailMerge = Nothing
            wordMergeFields = Nothing
            wordDoc = Nothing
            wordApp = Nothing

        End Sub

        Private Sub WordMailMerge1114_Activated()
            ' Write your code here.
            Property1 = "The DoMailMerge button creates a word document using the file c:\temp\MailMergeTemplate.dot"
        End Sub
    End Class

End Namespace
