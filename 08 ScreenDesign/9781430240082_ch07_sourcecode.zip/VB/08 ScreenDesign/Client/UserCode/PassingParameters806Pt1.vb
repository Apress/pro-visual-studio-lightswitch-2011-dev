﻿
Namespace LightSwitchApplication

    Public Class PassingParameters806Pt1

        Private Sub OpenSearchScreen_Execute()
            ' Write your code here.
            Me.Application.ShowPassingParameters806Pt2("Smith")
        End Sub
    End Class

End Namespace
