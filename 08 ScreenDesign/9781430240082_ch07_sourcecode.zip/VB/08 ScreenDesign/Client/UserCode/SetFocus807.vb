﻿
Namespace LightSwitchApplication

    Public Class SetFocus807

        Private Sub SetFocus807_InitializeDataWorkspace(saveChangesTo As System.Collections.Generic.List(Of Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Me.CustomerProperty = New Customer()
        End Sub

        Private Sub SetFocus807_Saved()
            ' Write your code here.
            Me.Close(False)
            Application.Current.ShowDefaultScreen(Me.CustomerProperty)
        End Sub

        Private Sub SetFocusToSurnameField_Execute()
            ' Write your code here.
            Me.FindControl("Surname").Focus()
        End Sub
    End Class

End Namespace