﻿Imports System.Windows.Controls
Imports Microsoft.LightSwitch.Threading
Imports System.Windows

Namespace LightSwitchApplication

    Public Class UploadingFiles826

        Private Sub UploadingFiles826_InitializeDataWorkspace(ByVal saveChangesTo As Global.System.Collections.Generic.List(Of Global.Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Me.ProductDocumentProperty = New ProductDocument()
        End Sub

        Private Sub UploadingFiles826_Saved()
            ' Write your code here.
            Me.Close(False)
            'Application.Current.ShowDefaultScreen(Me.ProductDocumentProperty)

            Application.Current.ShowDownloadingFileDetails827(ProductDocumentProperty.Id)
        End Sub

        Private Sub UploadingFiles826_Activated()
            ' Write your code here.
            Property1 = "Click on the upload file to database button. Click on the Save button afterwards"

        End Sub

        Private Sub UploadFileToDatabase_Execute()
            ' Write your code here.
            Dispatchers.Main.Invoke(Sub()

                                        Dim openDialog As New Controls.OpenFileDialog
                                        openDialog.Filter = "All files|*.*"

                                        'Use this syntax to only allow Word/Excel files
                                        'openDialog.Filter = "Word Files|*.doc|Excel Files |*.xls" 

                                        If openDialog.ShowDialog = True Then
                                            Using fileData As System.IO.FileStream = openDialog.File.OpenRead

                                                Dim fileLen As Long = fileData.Length

                                                If (fileLen > 0) Then
                                                    Dim fileBArray(fileLen - 1) As Byte
                                                    fileData.Read(fileBArray, 0, fileLen)
                                                    fileData.Close()

                                                    Me.ProductDocumentProperty.File = fileBArray
                                                    Me.ProductDocumentProperty.FileExtension =
                                                      openDialog.File.Extension.ToString()
                                                    Me.ProductDocumentProperty.FileName =
                                                      openDialog.File.Name

                                                End If

                                            End Using
                                        End If

                                    End Sub)

        End Sub

    End Class

End Namespace