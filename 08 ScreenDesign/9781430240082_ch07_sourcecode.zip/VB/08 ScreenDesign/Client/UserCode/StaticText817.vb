﻿
Namespace LightSwitchApplication

    Public Class StaticText817

        Private Sub StaticText817_Activated()
            ' Write your code here.
            ScreenTitle = "This text has been set in code!"

        End Sub
    End Class

End Namespace
