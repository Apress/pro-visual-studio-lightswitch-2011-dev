﻿
Namespace LightSwitchApplication

    Public Class SilverlightEvent811

        Private Sub SilverlightEvent811_InitializeDataWorkspace(saveChangesTo As System.Collections.Generic.List(Of Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Me.CustomerProperty = New Customer()

            Dim control = Me.FindControl("Surname")
            AddHandler control.ControlAvailable,
                AddressOf TextBoxAvailable

        End Sub

        Private Sub TextBoxAvailable(
    sender As Object, e As ControlAvailableEventArgs)
            AddHandler CType(e.Control, 
                System.Windows.Controls.TextBox).KeyUp,
                    AddressOf TextBoxKeyUp
        End Sub

        Private Sub TextBoxKeyUp(
    sender As Object, e As System.Windows.RoutedEventArgs)

            Dim textbox = CType(sender, System.Windows.Controls.TextBox)
            Dim textUppered As String = textbox.Text.ToUpper
            Dim selStart As Integer = textbox.SelectionStart
            textbox.Text = textUppered
            textbox.SelectionStart = selStart

        End Sub


        Private Sub SilverlightEvent811_Saved()
            ' Write your code here.
            Me.Close(False)
            Application.Current.ShowDefaultScreen(Me.CustomerProperty)
        End Sub

        Private Sub SilverlightEvent811_Activated()
            ' Write your code here.
            Property1 = "Type into the Surname field"

        End Sub
    End Class

End Namespace