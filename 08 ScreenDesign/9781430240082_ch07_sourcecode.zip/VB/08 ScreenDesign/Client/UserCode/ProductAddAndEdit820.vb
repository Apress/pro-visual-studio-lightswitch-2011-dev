﻿
Namespace LightSwitchApplication

    Public Class ProductAddAndEdit820

        Private Sub Product_Loaded(succeeded As Boolean)
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.ProductProperty)
        End Sub

        Private Sub Product_Changed()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.ProductProperty)
        End Sub

        Private Sub ProductAddAndEdit820_Saved()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.ProductProperty)
        End Sub

        Private Sub ProductAddAndEdit820_InitializeDataWorkspace(saveChangesTo As System.Collections.Generic.List(Of Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            If Not Me.ProductId.HasValue Then
                Me.ProductProperty = New Product()
            Else
                Me.ProductProperty = Me.Product
            End If

            Me.SetDisplayNameFromEntity(Me.ProductProperty)
        End Sub
    End Class

End Namespace