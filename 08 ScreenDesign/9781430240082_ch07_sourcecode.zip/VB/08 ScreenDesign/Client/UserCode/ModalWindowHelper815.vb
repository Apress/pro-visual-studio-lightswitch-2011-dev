﻿Imports System.Windows.Controls

Namespace LightSwitchApplication

    Public Class ModalWindowHelper815

        'Set LIST_CONTROL to the name of your data grid or control 
        'eg Grid or List 
        Private Const LIST_CONTROL As String = "grid"
        Private Const ITEM_WINDOW As String = "group"
        Private Const ITEM As String = "Customer"
        Private itemsControl As DataGrid = Nothing
        Private itemWindow As ModalWindowHelper

        Private Sub ModalWindowHelper815_InitializeDataWorkspace(saveChangesTo As System.Collections.Generic.List(Of Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            itemWindow =
            New ModalWindowHelper(Me.Customers, ITEM_WINDOW, entityName:=ITEM)

            AddHandler Me.FindControl(LIST_CONTROL).ControlAvailable,
             Sub(send As Object, e As ControlAvailableEventArgs)
                 itemsControl = TryCast(
                    e.Control, System.Windows.Controls.DataGrid)
             End Sub

        End Sub

        Private Sub ModalWindowHelper815_Activated()
            ' Write your code here.

        End Sub

        Private Sub ModalWindowHelper815_Created()
            ' Write your code here.
            itemWindow.Initialize(hasCloseButton:=True, saveOnClose:=True)
        End Sub


        Private Sub AddItem_CanExecute(ByRef result As Boolean)
            result = (itemWindow.CanAdd = True)
        End Sub

        Private Sub AddItem_Execute()
            itemWindow.AddEntity()
        End Sub
        Private Sub ViewItem_CanExecute(ByRef result As Boolean)
            result = (itemWindow.CanView = True)
        End Sub

        Private Sub ViewItem_Execute()
            itemWindow.ViewEntity()
        End Sub

        Private Sub SaveItem_Execute()
            itemWindow.DialogOk()
        End Sub

        Private Sub CancelItem_Execute()
            itemWindow.DialogCancel()
        End Sub



    End Class

End Namespace
