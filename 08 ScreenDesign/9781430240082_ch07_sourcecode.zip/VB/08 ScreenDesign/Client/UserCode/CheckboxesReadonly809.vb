﻿
Namespace LightSwitchApplication

    Public Class CheckboxesReadonly809

        Private Sub CheckboxesReadonly809_Activated()
            ' Write your code here.

        End Sub

        Private Sub Employees_Loaded(succeeded As Boolean)
            For Each emp In Employees
                Me.FindControlInCollection(
                    "SecurityVetted", emp).IsEnabled = False
            Next

        End Sub
    End Class

End Namespace
