﻿
Namespace LightSwitchApplication

    Public Class HideShowCtrls808

        Private Sub HideShowCtrls808_InitializeDataWorkspace(ByVal saveChangesTo As Global.System.Collections.Generic.List(Of Global.Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Me.CustomerProperty = New Customer()
        End Sub

        Private Sub HideShowCtrls808_Saved()
            ' Write your code here.
            Me.Close(False)
            Application.Current.ShowDefaultScreen(Me.CustomerProperty)
        End Sub

        Private Sub ToggleVisibility_Execute()
            ' Write your code here.
            Dim rowLayout = Me.FindControl("Group")
            rowLayout.IsVisible = Not (rowLayout.IsVisible)

        End Sub
    End Class

End Namespace