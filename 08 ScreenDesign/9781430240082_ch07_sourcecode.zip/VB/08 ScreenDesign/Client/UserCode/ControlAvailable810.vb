﻿Imports System.Windows.Media
Namespace LightSwitchApplication

    Public Class ControlAvailable810

        Private Sub ControlAvailable810_InitializeDataWorkspace(saveChangesTo As System.Collections.Generic.List(Of Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Me.CustomerProperty = New Customer()


            Dim control = Me.FindControl("Surname")

            AddHandler control.ControlAvailable,
                Sub(sender As Object, e As ControlAvailableEventArgs)
                    Dim textbox = CType(e.Control, 
                        System.Windows.Controls.TextBox)
                    textbox.Background = New SolidColorBrush(Colors.Yellow)
                End Sub


        End Sub

        Private Sub ControlAvailable810_Saved()
            ' Write your code here.
            Me.Close(False)
            Application.Current.ShowDefaultScreen(Me.CustomerProperty)
        End Sub

    End Class

End Namespace