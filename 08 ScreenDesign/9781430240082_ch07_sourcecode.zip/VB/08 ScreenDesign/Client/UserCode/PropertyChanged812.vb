﻿Imports System.ComponentModel

Namespace LightSwitchApplication

    Public Class PropertyChanged812

        Private Sub PropertyChanged812_InitializeDataWorkspace(ByVal saveChangesTo As Global.System.Collections.Generic.List(Of Global.Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Me.EmployeeProperty = New Employee()
        End Sub

        Private Sub PropertyChanged812_Saved()
            ' Write your code here.
            Me.Close(False)
            Application.Current.ShowDefaultScreen(Me.EmployeeProperty)
        End Sub

        Private Sub PropertyChanged812_Activated()
            ' Write your code here.

        End Sub

        Private Sub EmployeeFieldChanged(
    sender As Object, e As PropertyChangedEventArgs)
            If e.PropertyName = "SecurityVetted" Then
                Me.FindControl("group").IsVisible =
                   EmployeeProperty.SecurityVetted
            End If
        End Sub

        Private Sub PropertyChanged812_Created()
            ' Write your code here.
            Microsoft.LightSwitch.Threading.Dispatchers.Main.BeginInvoke(
  Sub()
      AddHandler DirectCast(
         Me.EmployeeProperty, INotifyPropertyChanged
         ).PropertyChanged, AddressOf EmployeeFieldChanged
  End Sub)

            'Set the initial visibility here
            Me.FindControl("group").IsVisible =
                EmployeeProperty.SecurityVetted

        End Sub
    End Class

End Namespace