﻿Imports System.ComponentModel
Namespace LightSwitchApplication

    Public Class PropertyChangedDetail813

        Private monitoredEmployee As Employee

        Private Sub PropertyChangedDetail813_InitializeDataWorkspace(
            saveChangesTo As System.Collections.Generic.List(
                Of Microsoft.LightSwitch.IDataService))

            Microsoft.LightSwitch.Threading.Dispatchers.Main.BeginInvoke(
               Sub()
                   AddHandler Me.Details.Properties.Employee.Loader.ExecuteCompleted,
                       AddressOf Me.EmployeeLoaderExecuted
               End Sub)
        End Sub



        Private Sub EmployeeLoaderExecuted(
            sender As Object, e As Microsoft.LightSwitch.ExecuteCompletedEventArgs)

            If monitoredEmployee IsNot Me.Employee Then
                If monitoredEmployee IsNot Nothing Then
                    RemoveHandler TryCast(monitoredEmployee, 
                        INotifyPropertyChanged).PropertyChanged,
                            AddressOf Me.EmployeeChanged
                End If

                monitoredEmployee = Me.Employee

                If monitoredEmployee IsNot Nothing Then
                    AddHandler TryCast(
                       monitoredEmployee, INotifyPropertyChanged).PropertyChanged,
                          AddressOf Me.EmployeeChanged

                    'Set the initial visibility here
                    Me.FindControl("group").IsVisible =
                        monitoredEmployee.SecurityVetted

                End If
            End If
        End Sub

        Private Sub EmployeeChanged(sender As Object, e As PropertyChangedEventArgs)

            If e.PropertyName = "SecurityVetted" Then
                Me.FindControl("group").IsVisible =
                    monitoredEmployee.SecurityVetted
            End If

        End Sub



        Private Sub Employee_Loaded(succeeded As Boolean)
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Employee)
        End Sub

        Private Sub Employee_Changed()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Employee)
        End Sub

        Private Sub PropertyChangedDetail813_Saved()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Employee)
        End Sub

    End Class

End Namespace