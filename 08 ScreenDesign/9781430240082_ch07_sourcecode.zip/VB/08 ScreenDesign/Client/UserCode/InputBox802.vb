﻿
Namespace LightSwitchApplication

    Public Class InputBox802

        Private Sub Customer_Loaded(succeeded As Boolean)
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Customer)
        End Sub

        Private Sub Customer_Changed()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Customer)
        End Sub

        Private Sub InputBox802_Saved()
            ' Write your code here.
            Me.SetDisplayNameFromEntity(Me.Customer)
        End Sub

        Private Sub InputBox802_Saving(ByRef handled As Boolean)
            ' Write your code here.
            Dim comment = Me.ShowInputBox(
    "Do you want to include any additional comments?",
    "Confirm Save", "")

            If Not comment Is Nothing AndAlso comment.Length > 0 Then
                Me.Customer.Comment = comment
            End If

        End Sub
    End Class

End Namespace