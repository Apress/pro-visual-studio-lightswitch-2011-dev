﻿
Namespace LightSwitchApplication

    Public Class OpenScreensFromCode805

        Private Sub OpenSearchScreen_Execute()
            ' Write your code here.
            Me.Application.ShowSearchCustomers()
        End Sub
    End Class

End Namespace
