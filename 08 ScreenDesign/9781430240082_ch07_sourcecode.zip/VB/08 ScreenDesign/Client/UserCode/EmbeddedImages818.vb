﻿
Namespace LightSwitchApplication

    Public Class EmbeddedImages818

        Private Sub EmbeddedImages818_Activated()
            ' Write your code here.
            ScreenLogo = GetImageFromAssembly("ScreenLogo.png")
        End Sub



        Private Function GetImageFromAssembly(
            fileName As String) As Byte()

            Dim assembly As Reflection.Assembly =
                Reflection.Assembly.GetExecutingAssembly()

            Dim stream As Stream =
                assembly.GetManifestResourceStream(fileName)

            Dim streamLength As Integer = CInt(stream.Length)

            Dim fileData(streamLength - 1) As Byte
            stream.Read(fileData, 0, streamLength)
            stream.Close()
            Return fileData

        End Function



    End Class

End Namespace
