﻿
Namespace LightSwitchApplication

    Public Class SetAutoCompleteBoxValueInCode816

        Private Sub SetAutoCompleteBoxValue_Execute()
            ' Write your code here.
            Me.CountryProperty =
   DataWorkspace.ApplicationData.Countries.Where(
       Function(country) country.CountryName = "England"
          ).FirstOrDefault()

        End Sub
    End Class

End Namespace
