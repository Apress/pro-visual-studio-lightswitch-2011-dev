﻿
Namespace LightSwitchApplication

    Public Class ManyToMany822

        Private Sub ManyToMany822_InitializeDataWorkspace(ByVal saveChangesTo As Global.System.Collections.Generic.List(Of Global.Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Me.ProductProperty = New Product()
        End Sub

        Private Sub ManyToMany822_Saved()
            ' Write your code here.
            Me.Close(False)
            Application.Current.ShowDefaultScreen(Me.ProductProperty)
        End Sub

        Private Sub AddAttribute_Execute()
            ' Write your code here.
            If (Attributes.SelectedItem IsNot Nothing) Then
                Dim prodAtt As ProductAttribute = ProductAttributesCollection.AddNew()
                prodAtt.Product = Me.ProductProperty
                prodAtt.Attribute = Attributes.SelectedItem
            End If


        End Sub

        Private Sub RemoveAttribute_Execute()
            ' Write your code here.
            ProductAttributesCollection.DeleteSelected()
        End Sub
    End Class

End Namespace