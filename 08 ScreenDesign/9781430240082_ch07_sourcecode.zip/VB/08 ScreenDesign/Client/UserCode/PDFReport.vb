﻿Imports PdfSharp
Imports PdfSharp.Drawing
Imports PdfSharp.Pdf


Namespace LightSwitchApplication

    Public Class PDFReport

        Private Sub DoPDF_Execute()
            ' Write your code here.
            Microsoft.LightSwitch.Threading.Dispatchers.Main.BeginInvoke(
            Sub()
                Dim document As New PdfDocument()
                document.Info.Title = "Dispatch Notice"

                ' Create an empty page
                Dim page As PdfPage = document.AddPage()

                ' Get an XGraphics object for drawing
                Dim gfx As XGraphics = XGraphics.FromPdfPage(page)

                ' Create a font
                Dim fontHeader1 As New XFont("Verdana", 18, XFontStyle.Bold)
                Dim fontHeader2 As New XFont("Verdana", 14, XFontStyle.Bold)
                Dim fontNormal As New XFont("Verdana", 12, XFontStyle.Regular)

                ' Create the report text
                gfx.DrawString("ShipperCentral Dispatch", fontHeader1, XBrushes.Black, New XRect(5, 5, 200, 18), XStringFormats.TopCenter)

                gfx.DrawString("Thank you for shopping......", fontNormal, XBrushes.Black, New XRect(5, 18, 200, 18), XStringFormats.TopLeft)

                gfx.DrawString("Order Number: " + "1", fontHeader2, XBrushes.Black, New XRect(5, 32, 200, 18), XStringFormats.TopLeft)
                '.... create other Elements here

                ' Save the document here
                Dim myDocuments As String = Environment.GetFolderPath(
                    Environment.SpecialFolder.MyDocuments)

                document.Save(myDocuments & "\DispatchNotice.pdf")

                Me.ShowMessageBox("A PDF Report has been saved into My Documents\DispatchNotice.pdf")

            End Sub
            )

        End Sub
    End Class

End Namespace
