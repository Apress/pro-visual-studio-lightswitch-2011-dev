﻿Imports System.Windows.Controls



Namespace LightSwitchApplication

    Public Class MultiSelectGrid823

        Private WithEvents _datagridControl As DataGrid = Nothing

        Private Sub MultiSelectGrid823_Activated()
            ' Write your code here.
            Property1 = "Select Multiple rows using the ctrl key, click on the Update Statuses button to update highlighted rows"

        End Sub

        Private Sub MultiSelectGrid823_Created()
            'Replace grid with the name of your data grid control
            AddHandler Me.FindControl("grid").ControlAvailable,
                Sub(send As Object, e As ControlAvailableEventArgs)

                    _datagridControl = TryCast(e.Control, DataGrid)
                    _datagridControl.SelectionMode = DataGridSelectionMode.Extended

                End Sub


        End Sub

        Private Sub UpdateStatuses_Execute()
            ' Write your code here.

            'Dim shippedStatus =
            '    DataWorkspace.ApplicationData.OrderStatusSet.Where(
            '        Function(item) item.Id = 3).FirstOrDefault()

            'For Each ord As Order In _datagridControl.SelectedItems
            '    ord.OrderStatus = shippedStatus
            'Next

            For Each ord As Order In _datagridControl.SelectedItems
                ord.OrderStatus = OrderStatusProperty
            Next


        End Sub
    End Class

End Namespace
