﻿
Namespace LightSwitchApplication

    Public Class OpenInAddMode821

        Private Sub OpenCombinedScreenInAddMode_Execute()
            ' Write your code here.
            Me.Application.ShowProductAddAndEdit820(Nothing)

        End Sub

    End Class

End Namespace
